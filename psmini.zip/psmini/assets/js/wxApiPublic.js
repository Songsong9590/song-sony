const loginService = require("../../service/loginService.js");
const service = require("../../service/service");
var config = require('../../utils/config.js');
/**
 * 微信授权
 * */

// 微信授权 val 自定义参数 isSubmit 是否重新调用微信授权接口  typeName 为空 调用wxAuthorizationCommont（）方法    1 调用 wxAuthorizationFun 方法
let weChatAuthorization = (e, that, val, isSubmit, typeName) => {
    // 点击允许获取授权信息后
    if (e.detail.errMsg == "getUserInfo:ok") {
        wx.checkSession({
            success(res) {
                console.log(res, 'session_key成功')
                authorizationInfo(e, that, val, isSubmit, typeName)
                //session_key 未过期，并且在本生命周期一直有效
            },
            fail() {
                // console.log(res, 'session_key失败')
                saveSessionKeyFun(e, that, val, isSubmit, typeName)
            }
        })
    }
}
// 重新调用 saveSessionKey
let saveSessionKeyFun = (e, that, val, isSubmit, typeName) => {
    // session_key 已经失效，需要重新执行登录流程
    wx.login({
        success: res => {
            var formData = {
                code: res.code
            }
            loginService.saveSessionKey(formData).then(res => {
                // console.log(res,'保存微信 sessionkey')
                if (res.data.code == 200) {
                    authorizationInfo(e, that, val, isSubmit, typeName)
                } else {
                    if (!isSubmit) {
                        weChatAuthorization(e, that, val, true, typeName) // 微信授权失败重新调用授权接口  仅调用一次
                    }
                    wx.showToast({
                        title: res.data.message,
                        icon: 'none',
                        duration: 2000
                    })
                }

            })
        }
    })
}
// 保存微信信息接口方法
let authorizationInfo = (e, that, val, isSubmit, typeName) => {
    var formData = {
        encryptedData: e.detail.encryptedData,
        iv: e.detail.iv,
        // code: res.code
    }
    loginService.khxxaddUserInfo(formData).then(res => {
        console.log(res, '提交用户头像和昵称')
        if (res.data.code == 200) {
            // if (typeName == '1') {
            //     that.wxAuthorizationFun(val) // 保存成功之后调用公共接口  当前页有两个授权接口时 调用
            // } else {
            that.wxAuthorizationCommont(val, typeName) // 保存成功之后调用公共接口
            // }
        } else {
            console.log(isSubmit, 'isSubmit')
            if (!isSubmit) {
                // weChatAuthorization(e, that, val, true, typeName) // 微信授权失败重新调用授权接口  仅调用一次
                saveSessionKeyFun(e, that, val, true, typeName) // 微信授权失败重新调用授权 SessionKey 接口
            }
            wx.showToast({
                title: res.data.message,
                icon: 'none',
                duration: 2000
            })
        }
    })
}

/**
 * 手机号授权
 * */

// 手机号授权  type // 1 直接跳转   2 还有其他操作 , navurl
let getMobilePhone = (self, e, navurl, type, typeName) => {
    if (e.detail.errMsg == "getPhoneNumber:ok") {
        wx.checkSession({
            success(res) {
                console.log(res, 'session_key手机号成功')
                savePhone(self, e, navurl, type, typeName)
                //session_key 未过期，并且在本生命周期一直有效
            },
            fail() {
                // console.log(res, 'session_key失败')
                // session_key 已经失效，需要重新执行登录流程
                wx.login({
                    success: res => {
                        var formData = {
                            code: res.code
                        }
                        loginService.saveSessionKey(formData).then(res => {
                            // console.log(res,'保存微信 sessionkey')
                            if (res.data.code == 200) {
                                savePhone(self, e, navurl, type, typeName)
                            } else {
                                if (!isSubmit) {
                                    getMobilePhone(self, e, navurl, type, typeName) // 微信授权失败重新调用授权接口  仅调用一次
                                }
                                wx.showToast({
                                    title: res.data.message,
                                    icon: 'none',
                                    duration: 2000
                                })
                            }

                        })
                    }
                })
            }
        })



    }
}

let savePhone = (self, e, navurl, type, typeName) => {
    // 无手机号
    var encryptedData = e.detail.encryptedData;
    var iv = e.detail.iv;
    //   wx.login({
    //       success: res => {
    var data = {
        "encryptedData": encryptedData,
        "iv": iv,
        //   "code": res.code
    }
    // 登录
    loginService.addPhone(data).then(res => {
        // console.log(res, '授权手机号')
        if (res.data.code == 200) {
            if (typeName == '1') {
                self.commonMobilePhoneFun2(navurl, type, res)
            } else {
                self.commonMobilePhoneFun(navurl, type, res)
                console.log(navurl, type, res, self)
            }
            // if (type == '1') { // 直接跳转
            //     wx.navigateTo({
            //         url: navurl
            //     })
            // } else {
            //     self.setData({
            //         phone: res.data.data
            //     })
            //     // commonType
            //     let commonType = 2 // 调用公用方法  1 一进页面每次都需调用   2 制定当前方法
            //     self.commonMobilePhoneFun(commonType)
            // }
        } else {
            wx.showToast({
                title: res.data.message,
                icon: 'none',
                duration: 2000,
            })
        }
    })
    //       }
    //   })
}

/**
 * 文件上传
 * */
// 上传图片  count 上传数量
let chooseImageNumBtn = (that, count, imgName) => {
    wx.chooseImage({
        count: count,
        sizeType: ['original', 'compressed'],
        sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有  
        success(res) {
            wx.showLoading({
                title: '上传图片中',
            })
            // console.log(res)
            res.tempFilePaths.forEach(item => {
                uploadFile(item, 1, that, imgName); //图片上传每次一张  每次遍历都调用这个借口
            });
        }
    })
}
// 上传视频  count 上传数量
let chooseVideoBtn = (that, count, imgName) => {
    wx.chooseVideo({
        sourceType: ['album', 'camera'],
        maxDuration: 60,
        camera: 'back',
        success(res) {
            wx.showLoading({
                title: '上传视频中',
            })
            uploadFile(res.tempFilePath, 2, that, imgName); //图片上传每次一张  每次遍历都调用这个借口
        }
    })
}

// 上传音频  
let chooseVoiceFrequencyBtn = (that, recorderManager, d_luyinIconList, imgName) => {
    // isRecording 是否开始录音
    if (that.data.isRecording) {
        // 开始录音
        const option = {
            duration: 600000,
            sampleRate: 16000,
            numberOfChannels: 1,
            encodeBitTate: 96000,
            format: 'mp3',
            frameSize: 50
        }
        // 开始
        recorderManager.start(option);
        recorderManager.onStart(() => {
            console.log('recorder start')
        })
        // 错误回调
        recorderManager.onError((res) => {
            console.log(res);
        })
        that.setData({
            luyinIconList: d_luyinIconList[1]
        })
    } else {
        // 结束录音
        recorderManager.stop();
        recorderManager.onStop((res) => {
            console.log(res, 'res')
            // duration  录音总时长
            that.setData({
                duration: res.duration
            })
            uploadFile(res.tempFilePath, 3, that, imgName); //图片上传每次一张  每次遍历都调用这个借口
        })
        that.setData({
            luyinIconList: d_luyinIconList[0]
        })
    }
}

// 上传图片 公共方法 uploadType 1 图片上传   2 视频上传  3 上传音频    imgName 自定义参数
let uploadFile = (url, uploadType, that, imgName) => {
    const token = wx.getStorageSync('token') || '';
    wx.uploadFile({
        url: config.DOMAIN + '/common/auth/upload', //将图片传到服务器的请求路径
        filePath: url, //图片在手机里的存储路径
        name: 'file',
        header: {
            "Content-Type": "multipart/form-data",
            "X-Auth-Token": token
        },
        formData: {
            'user': 'test'
        },
        success(res) {
            wx.hideLoading();
            const mata = JSON.parse(res.data)
            if (uploadType == 1) { // 上传图片地址
                // 把数据存到imglist中去
                var url = config.DOMAIN + mata.fileUpload.fileUrl
                that.imgUploadComment(url, imgName) // 上传图片之后公共调用方法
            } else if (uploadType == 2) {
                // 把数据存到imglist中去
                var url = config.DOMAIN + mata.fileUpload.fileUrl
                that.videoUploadComment(url, imgName) // 上传视频之后公共调用方法
            } else if (uploadType == 3) {
                // 把数据存到imglist中去
                var url = config.DOMAIN + mata.fileUpload.fileUrl
                that.VoiceFrequencyUploadComment(url, imgName) // 上传音频之后公共调用方法
            }
        },
        fail(res) {
            wx.hideLoading();
            // 上传失败
            wx.showToast({
                title: '上传失败',
                icon: 'none',
                duration: '2000'
            })
        },
    })
}


// 收藏 
let collectionFun = (id, that, type, prevPage, productList, isLike, speedDetail) => {
    // 详情id, that(当前详情页data), prevPage（上一页data）, productList（上一页产品列表是否收藏）, isLike, speedDetail（当前详情页面是否收藏）
    // console.log(id, prevPage, productList, isLike, speedDetail,'详情id, that(当前详情页data), prevPage（上一页data）, productList（上一页产品列表是否收藏）, isLike, speedDetail（当前详情页面是否收藏）')
    // isLike    1喜欢 0 不喜欢
    var formData = {
        comet: id, //公用id
        type: type, //收藏类型 1 产品 2 应用 3 新闻 4 话题   5活动（目前只有海事展）  6 电商产品  
    }
    service.collectionScOrQx(formData).then(res => {
        // console.log(res, '收藏', isLike)
        if (res.data.code == 202) { //收藏成功
            that.setData({
                [speedDetail]: true
            })
            if (prevPage) {
                prevPage.setData({
                    [productList]: true
                }) //设置数据
            }
        } else if (res.data.code == 201) { //取消收藏
            that.setData({
                [speedDetail]: false
            })
            if (prevPage) {
                prevPage.setData({
                    [productList]: false
                }) //设置数据
            }
        } else {
            wx.showToast({
                title: res.data.message,
                icon: 'none',
                duration: 2000
            })
        }
    })
}


// 定制支付
/**
 * 参数
 *  data 传参   
 * type 支付类型  1 标准商品   2 定制商品   3 购物车列表   4 预支付
 * orderMxList  商品列表
 *  psFs   配送方式 1自提 2 外送   3 虚拟
 * dzid   地址id
 * id    订单重新支付时使用
 *  mjly   买家留言
 * yhqid    优惠券id
 * mdid    门店id
 * vipCardId   客户会员卡id
 * original   小程序原始id
 * payWay   支付方式   1 全额支付   2 分期支付
 * payNumberPeriods     分期期数
 * contentId   线索id  type 为定制商品时上传
 * 
 * */
// payType  下单方式  正常下单  2 待支付列表下单
// orderType  订单类型  1 普通商品   2  定制商品
let customizationPay = (data, payType, orderType, prevPage) => {
    var that = this;
    wx.showModal({
        title: "",
        content: '确定支付？',
        confirmColor: '#FF9600',
        success(res) {
            if (res.confirm) {
                if (prevPage) {
                    prevPage.setData({
                        isShoppingList: true
                    })
                }
                wx.showLoading({
                    title: '加载支付数据',
                })
                loginService.aredaPay(data).then(res => {
                    // console.log(res, '购买');
                    wx.hideLoading();
                    if (res.data.code == 200) {
                        if (res.data.data.length == 2) {
                            var message = JSON.parse(res.data.data[0]);
                            var orderId = res.data.data[1];
                            wx.requestPayment({
                                'timeStamp': message.timeStamp,
                                'nonceStr': message.nonceStr,
                                'package': message.package,
                                'signType': message.signType,
                                'paySign': message.paySign,
                                'success': function (res) {
                                    wx.showToast({
                                        title: '支付成功',
                                    })
                                    // payType  下单方式  正常下单  2 待支付列表下单
                                    if (payType == 1) {
                                        // orderType  订单类型  1 普通商品   2  定制商品
                                        if (orderType == 1) { // 普通商品  跳转至分享页面
                                            var rel = setTimeout(function () {
                                                if (isLift == 1) { //自提     isLift 1 自提  2 外送
                                                    var name = '6'
                                                } else {
                                                    var name = '3'
                                                }
                                                wx.redirectTo({
                                                    url: '/pages/mine/orderRecord/orderRecord?pay=1&name=' + name,
                                                })
                                                clearInterval(rel)
                                            }, 200)
                                        } else if (orderType == 2) {
                                            // 定制商品
                                            wx.navigateBack({
                                                delta: 1,
                                            })
                                            // var rel = setTimeout(function () {
                                            //     // ordertype  1 商品订单   2 定制订单
                                            //     // name  3 待发货
                                            //     wx.redirectTo({
                                            //         url: '/pages/mine/orderRecord/orderRecord?pay=1&name=3&ordertype=2',
                                            //     })
                                            //     clearInterval(rel)
                                            // }, 200)

                                        }
                                    } else if (payType == 2) { //待支付
                                        wx.navigateBack({
                                            delta: 1,
                                        })
                                    }


                                },
                                'fail': function (res) {
                                    wx.hideLoading();
                                    wx.showToast({
                                        title: '支付失败',
                                        icon: 'none',
                                        duration: 2000
                                    })
                                    // orderType  订单类型  1 普通商品   2  定制商品
                                    if (orderType == 1) { // 普通商品  跳转至分享页面
                                        var rel = setTimeout(function () {
                                            wx.redirectTo({
                                                url: '/pages/mine/orderDetail/orderDetail?id=' + orderId + '&name=3',
                                            })
                                            clearInterval(rel)
                                        }, 200)
                                    } else if (orderType == 2) {
                                        // 定制商品
                                        wx.navigateBack({
                                            delta: 1,
                                        })
                                    }
                                }
                            })
                        } else if (res.data.data.length == 1) {
                            var orderId = res.data.data[0];
                            if (payType == 1) {
                                //         // 跳转至分享页面
                                // orderType  订单类型  1 普通商品   2  定制商品
                                if (orderType == 1) { // 普通商品  跳转至分享页面
                                    var rel = setTimeout(function () {
                                        // redirectTo   /pages/mine/orderRecord/orderRecord?name=4
                                        if (isLift == 1) { //自提
                                            var name = '6'
                                        } else {
                                            var name = '1'
                                        }
                                        wx.redirectTo({
                                            url: '/pages/mine/orderRecord/orderRecord?pay=1&name=' + name,
                                        })
                                        clearInterval(rel)
                                    }, 200)
                                } else if (orderType == 2) {
                                    // 定制商品
                                     // 定制商品
                                     wx.navigateBack({
                                        delta: 1,
                                    })
                                    // var rel = setTimeout(function () {
                                    //     // ordertype  1 商品订单   2 定制订单
                                    //     // name  1 代付款 3 待发货
                                    //     wx.redirectTo({
                                    //         url: '/pages/mine/orderRecord/orderRecord?pay=1&name=1&ordertype=2',
                                    //     })
                                    //     clearInterval(rel)
                                    // }, 200)

                                }
                            } else if (payType == 2) { //待支付
                                wx.navigateBack({
                                    delta: 1,
                                })
                            }
                        } else {
                            wx.showToast({
                                title: res.data.data.message,
                                icon: 'none',
                                duration: 2000
                            })
                        }
                    } else {
                        wx.showToast({
                            title: res.data.message,
                            icon: 'none',
                            duration: 2000
                        })
                    }
                })
            }
        }
    })
}
module.exports = {
    // 保存微信信息
    weChatAuthorization,
    authorizationInfo,

    // 保存手机号信息
    getMobilePhone,

    // 上传图片
    chooseImageNumBtn,
    // 上传文件
    uploadFile,
    // 上传视频
    chooseVideoBtn,
    // 上传音频
    chooseVoiceFrequencyBtn,

    // 收藏
    collectionFun,

    // 支付
    customizationPay
}
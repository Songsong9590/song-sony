
const loginService = require("../../service/loginService.js");
// 获取token 登录
let getLoginToken = (khid, staffid, sourceId,that) => {
  wx.login({
    success: res => {
      var formData = {
        'code': res.code,
        'recId': khid,
        'sourceId': sourceId,
        'recstaffId': staffid
      }
      // 发送 res.code 到后台换取 openId, sessionKey, unionId
      loginService.loginP(formData).then(res => {
        console.log(res, '登录首页')
        that.data.isRefresh = true
        if (res.data.code == 200) {
          wx.setStorage({
            key: 'token',
            data: res.data.data.khxx ? res.data.data.khxx.token : res.data.data.token,
          })
          var z = setInterval(function () {
            that.commonFun() // 公共方法
            clearInterval(z)
          }, 1000)
        } else {
          common.showToast(res.data.message)
        }
      })
    }
  })
}



module.exports = {
  getLoginToken
}
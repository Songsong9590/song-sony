// 获取当前日期和当前屏幕尺寸
let getDateFun = (that) => {
    const date = new Date();
    var year = date.getFullYear()
    var month = date.getMonth() + 1
    var day = date.getDate()
    var chnMonArr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12] // 中文参照
    var currentMonth = month // 月份中文名
    var enMonArr = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Spt', 'Oct', 'Nov', 'Dec'] // 英文月份
    for (var i = 0; i < chnMonArr.length; i++) { // 循环匹配
        if (currentMonth === chnMonArr[i]) {
            // console.log(currentMonth, 'currentMonth33333', enMonArr[i])
            month = enMonArr[i]
        }
    }
    // if (month < 10) {
    //     month = '0' + month
    // }
    if (day < 10) {
        day = '0' + day
    }
    wx.getSystemInfo({
        success: function (res) {
            that.setData({
                canvasWidth: res.windowWidth,
                canvasHeight: res.windowHeight,
                year: year,
                moth: month,
                day: day,
            })
        }
    })
}



// 验证手机号
let validation = (phone) => {
    var a = true;
    if (!phone) {
        wx.showToast({
            title: '手机号格式不能为空',
            icon: 'none',
            duration: 2000
        })
        return false;
    }
    var myreg = /^1[3456789]\d{9}$/;
    if (!myreg.test(phone)) {
        wx.showToast({
            title: '手机号格式不正确',
            icon: 'none',
            duration: 2000
        })
        return false;
    }
}
// 验证邮箱
let emailVerify = (email) => {
    var a = true;
    if (!email) {
        wx.showToast({
            title: '邮箱不能为空',
            icon: 'none',
            duration: 2000
        })
        return false;
    }
    let regEmail = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    if (!regEmail.test(email)) {
        wx.showToast({
            title: '请输入正确的邮箱',
            icon: 'none',
            duration: 2000
        })
        return false;
    }
}
// 弹出框
let showToast = (data) => {
    wx.showToast({
        title: data,
        icon: 'none',
        duration: 2000
    })
}

// 页面标题title修改
let setNavigationBarTitle = (data) => {
    wx.setNavigationBarTitle({
        title: data,
    })
}

// 订阅模板
let requestSubscribeMessage = (tmplIds) => {
    wx.requestSubscribeMessage({
        tmplIds: tmplIds,
        //   tmplIds: ['1Gq0G-aKLnQJjgnpVaAet29JKN2VRNuwO0B1_EZlIcU'],
        success(res) { },
        complete(res) {
        }
    })
}

// 拨打电话
let makePhoneCallBtn = (phone) => {
    wx.makePhoneCall({
        phoneNumber: phone //仅为示例，并非真实的电话号码
        //   phoneNumber: '4009976911' //仅为示例，并非真实的电话号码

    })
}

// 上传视频
let chooseVideoBtn = (that) => {
    wx.chooseVideo({
        sourceType: ['album', 'camera'], // album(从相册选择视频)     camera(使用相机拍摄视频) 
        maxDuration: 60, // 拍摄视频最长拍摄时间，单位秒
        camera: 'back', // 默认拉起的是前置或者后置摄像头。
        success(res) {
            // console.log(res.tempFilePath)
        }
    })
}

// 上传图片  count 上传数量
let chooseImageBtn = (that,count) => {
    wx.chooseImage({
        count: count,
        sizeType: ['original', 'compressed'],
        sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有  
        success(res) {
            // console.log(res)
            res.tempFilePaths.forEach(item => {
                that.uploadFile(item, ulIndex, 1); //图片上传每次一张  每次遍历都调用这个借口
            });
        }
    })
}

// 复制
let setClipboardBtn = (that,val) => {
    wx.setClipboardData({
        data: val,
        success(res) {
            wx.getClipboardData({
                success(res) {
                    // console.log(res.data) // data
                }
            })
        }
    })
}
module.exports = {
    validation,
    showToast,
    setNavigationBarTitle,
    emailVerify,
    getDateFun,
    requestSubscribeMessage,
    makePhoneCallBtn,
    chooseVideoBtn,
    chooseImageBtn,
    setClipboardBtn
}
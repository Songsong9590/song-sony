const goodsService = require("../../service/goodsService");
const config = require('../../utils/config.js');

// 购物车数量
let getgoodsCacheNum = (that) => {
  // var that = this;
  goodsService.goodsCache().then(res => {
    // console.log(res, '查询购物车数量')
    if (res.data.code == 200) {
      if (res.data.data.length > 0) {
        // wx.setTabBarBadge({//这个方法的意思是，为小程序某一项的tabbar右上角添加文本
        //   index: 3,   //代表哪个tabbar（从0开始）
        //   text: (res.data.data.length).toString()		//显示的内容
        // })
      } else {
        //   移除 tabBar 某一项右上角的文本
        // wx.removeTabBarBadge({
        //   index: 3,   //代表哪个tabbar（从0开始）
        // })
      }
    } else {
      //   移除 tabBar 某一项右上角的文本
      // wx.removeTabBarBadge({
      //   index: 3,   //代表哪个tabbar（从0开始）
      // })
    }
  })
}

module.exports = {
  getgoodsCacheNum
}
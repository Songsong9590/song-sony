// vipService.js
const wxRequest = require('../api/wxRequest.js');
const config = require('../utils/config.js');

/**
 * 购买会员卡
 * cardid   会员卡id
 * */
function buyVipCard(data) {
    var url = config.DOMAIN + '/shipApi/vip/buyVipCard';

    return wxRequest.postRequest(url, data);
}

/**
 * 获取所有会员卡
 * khVipCardid   用户会员卡id
 * */
function getVipCardAll(data) {
    var url = config.DOMAIN + '/shipApi/vip/getVipCardAll';

    return wxRequest.getRequest(url, data);
}

/**
 * 用户会员卡详情
 * khVipCardid   用户会员卡id
 * */
function getKhVipCard(data) {
    var url = config.DOMAIN + '/shipApi/vip/khVipCard';

    return wxRequest.getRequest(url, data);
}
/**
 * 用户会员卡列表
 * page   
 * size
 * */
function getVipCard(data) {
    var url = config.DOMAIN + '/shipApi/vip/vipCard';

    return wxRequest.getRequest(url, data);
}



// 购买会员 发送验证码
function vipSendRegisterSms(data) {
    var url = config.DOMAIN + '/shipApi/vip/send-register-sms';
    return wxRequest.postRequest(url, data);

}


// 购买会员 验证手机号
function vipVerifyRegisterSms(data) {
    var url = config.DOMAIN + '/shipApi/vip/verify-register-sms';
    return wxRequest.postRequest(url, data);
}

// 判断是否有会员卡  每人只能有一张
function vipIsbuy(data) {
    var url = config.DOMAIN + '/shipApi/vip/isbuy';
    return wxRequest.postRequest(url, data);
}


// 创建会员卡二维码
function vipCreateQrcode(data) {
    var url = config.DOMAIN + '/shipApi/vip/createQrcode';
    return wxRequest.postRequest(url, data);
}


// 会员卡二维码 是否消费
function vipIsSweepCode(data) {
    var url = config.DOMAIN + '/shipApi/vip/isSweepCode';
    return wxRequest.postRequest(url, data);
}
module.exports = {
    buyVipCard,
    getKhVipCard,
    getVipCardAll,
    getVipCard,
    vipSendRegisterSms,
    vipVerifyRegisterSms,
    vipIsbuy,
    vipCreateQrcode,
    vipIsSweepCode
}
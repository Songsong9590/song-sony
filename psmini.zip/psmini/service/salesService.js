/**
 * 销售接口
 * 
 * 数据层
 * 专注提供数据到view层
 * 上册 => api层 服务端接口请求，接口状态管理
 * 下层 => view层 业务逻辑
 * 
 */
const wxRequest = require('../api/wxRequest.js');
const config = require('../utils/config.js');

/**
 * getRequest:     get
 * putRequest:     put
 * postRequest     post
 */

/**
 * 获取销售订单列表
 * */
function  getOrderList(data) {
    var url = config.NODOMAIN + '/shipApi/order_sony/get_order_list_new';
    return wxRequest.postRequest(url, data);
}

function  getSalesList(data) {
    var url = config.NODOMAIN + '/shipApi/order_sony/get_order_list';
    return wxRequest.postRequest(url, data);
}

/**
 * 审核销售订单
 * */
function changeStatus(data) {
    var url = config.NODOMAIN + '/shipApi/order_sony/change_status';
    return wxRequest.postRequest(url, data);
}

/**
 * 新增销售订单
 * */
function saveSalesOrder(data) {
    var url = config.NODOMAIN + '/shipApi/order_sony/insert_order';
    return wxRequest.postRequest(url, data);
}

/**
 * 修改销售订单
 * */
function updateSalesOrder(data) {
    var url = config.NODOMAIN + '/shipApi/order_sony/upd_order';
    return wxRequest.postRequest(url, data);
}

/**
 * 修改销售订单
 * */
function getSalesCount(data) {
    var url = config.NODOMAIN + '/shipApi/spkc/getsaletjByZongdai';
    return wxRequest.getRequest(url, data);
}

module.exports = {
  getOrderList,
  changeStatus,
  saveSalesOrder,
  updateSalesOrder,
  getSalesList,
  getSalesCount
}
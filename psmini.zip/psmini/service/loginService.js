/**
 * 登录接口
 * 
 * 数据层
 * 专注提供数据到view层
 * 上册 => api层 服务端接口请求，接口状态管理
 * 下层 => view层 业务逻辑
 * 
 */
const wxRequest = require('../api/wxRequest.js');
const config = require('../utils/config.js');

/**
 * getRequest:     get
 * putRequest:     put
 * postRequest     post
 */

/**
 * 登录等不需要token验证的接口
 * */
function loginP(data) {
    var url = config.DOMAIN + '/shipApi/jxsUser/login';
    return wxRequest.postRequest(url, data);
}
/**
 * 保存微信头像昵称
 * */
// function saveAvatarAndNickname(data) {
//     var url = config.DOMAIN + '/common/khxx/saveAvatarAndNickname';
//     data.program = config.PROGRAM
//     return wxRequest.postRequest(url, data);
// }

/**
 * 保存微信用户信息  获取unionid
 * */
function khxxaddUserInfo(data) {
    var url = config.DOMAIN + '/shipApi/khxx/addUserInfo';
    // data.program = config.PROGRAM
    data.original = config.ORIGINAL // 小程序原始id
    
    return wxRequest.postRequest(url, data);
}

/**
 * 保存微信 sessionkey
 * */
function saveSessionKey(data) {
    var url = config.DOMAIN + '/shipApi/khxx/saveSessionKey';
    // data.program = config.PROGRAM
    data.original = config.ORIGINAL // 小程序原始id
    return wxRequest.postRequest(url, data);
}

/**
 * 保存小程序用户信息
 * @param code string
 * */
function authLogin(data) {
    var url = config.DOMAIN + '/common/auth/login';
    return wxRequest.postRequest(url, data);
}

/**
 * 保存小程序用户信息
 * @param nickname string
 * @param img string
 * */
function saveUserInfo(data) {
    var url = config.NODOMAIN + '/common/khxx/saveAvatarAndNickname';
    return wxRequest.postRequest(url, data);
}

/**
 * 获取小程序用户信息
 * @param nickname string
 * @param img string
 * */
function getUserInfo(data) {
    var url = config.NODOMAIN + '/common/khxx/userInfo';
    return wxRequest.getRequest(url, data);
}

/**
 * 获取销售统计数据
 * @param userid string
 * */
function getsaletj(data) {
    var url = config.NODOMAIN + '/shipApi/spkc/getsaletj';
    return wxRequest.getRequest(url, data);
}

/**
 * 获取首页图片
 * */
function getsypic(data) {
    var url = config.NODOMAIN + '/common/auth/getsypic';
    return wxRequest.getRequest(url, data);
}

/**
 * 获取待办事项
 * */
function getDaiBan(data) {
    var url = config.NODOMAIN + '/shipApi/order_sony/getDaiBan';
    return wxRequest.getRequest(url, data);
}


module.exports = {
    loginP,
    // saveAvatarAndNickname,
    khxxaddUserInfo,
    saveSessionKey,
    authLogin,
    saveUserInfo,
    getUserInfo,
    getsaletj,
    getsypic,
    getDaiBan
}
const wxRequest = require('../api/wxRequest.js');
const config = require('../utils/config.js');

/**
 * getRequest:     get
 * putRequest:     put
 * postRequest     post
 */

/**
 * 获取总代理下所有销售任务
 * */
function  getTotalSaleTask(data) {
    var url = config.NODOMAIN + '/shipApi/sp/getTotalSaleTask';
    return wxRequest.getRequest(url, data);
}

/**
 * 获取经销商下所有销售任务
 * */
function getTheSubJxsTask(data) {
    var url = config.NODOMAIN + '/shipApi/sp/getTheSubJxsTask';
    return wxRequest.getRequest(url, data);
}

/**
 * 获取门店销售任务
 * */
function getSaleTasksByStore(data) {
    var url = config.NODOMAIN + '/shipApi/sp/getSaleTasksByStore';
    return wxRequest.getRequest(url, data);
}

/**
 * 创建任务
 * */
function depolyTaskToStores(data) {
    var url = config.NODOMAIN + '/shipApi/sp/depolyTaskToStores';
    return wxRequest.postRequest(url, data);
}

/**
 * 获取门店销售任务
 * */
function getJxsUsersTasks(data) {
  var url = config.NODOMAIN + '/shipApi/sp/getJxsUsersTasks';
  return wxRequest.getRequest(url, data);
}

/**
 * 获取指定用户测验结果
 * */
function getAllExamResults(data) {
    var url = config.NODOMAIN + '/shipApi/jxsUser/getAllExamResults';
    return wxRequest.getRequest(url, data);
}

module.exports = {
  getTotalSaleTask,
  getTheSubJxsTask,
  getSaleTasksByStore,
  depolyTaskToStores,
  getJxsUsersTasks,
  getAllExamResults
}
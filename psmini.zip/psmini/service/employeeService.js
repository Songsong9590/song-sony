/**
 * 登录接口
 * 
 * 数据层
 * 专注提供数据到view层
 * 上册 => api层 服务端接口请求，接口状态管理
 * 下层 => view层 业务逻辑
 * 
 */
const wxRequest = require('../api/wxRequest.js');
const config = require('../utils/config.js');

/**
 * getRequest:     get
 * putRequest:     put
 * postRequest     post
 */

/**
 * 获取所有门店列表
 * */
function getStoreList(data) {
    var url = config.NODOMAIN + '/shipApi/store/getUserStoreList';
    return wxRequest.getRequest(url, data);
}

/**
 * 获取门店店员
 * */
function getStoreUser(data) {
    var url = config.NODOMAIN + '/shipApi/jxsUser/getStoreUser';
    return wxRequest.getRequest(url, data);
}

/**
 * 新增门店店员
 * */
function saveStoreEmployee(data) {
    var url = config.NODOMAIN + '/shipApi/jxsUser/addJxsUser';
    return wxRequest.postRequest(url, data);
}

/**
 * 获取账号信息
 * */
function getUserInfo(data) {
    var url = config.NODOMAIN + '/shipApi/jxsUser/getJxsUserInfo';
    return wxRequest.getRequest(url, data);
}

/**
 * 店员审批
 * */
function updateUserStatus(data) {
    var url = config.NODOMAIN + '/shipApi/jxsUser/updUserStatus';
    return wxRequest.postRequest(url, data);
}

/**
 * 新增门店
 * */
function saveStore(data) {
    var url = config.NODOMAIN + '/shipApi/jxsUser/addStore';
    return wxRequest.postRequest(url, data);
}

/**
 * 修改门店信息 
 * */
function updateStore(data) {
    var url = config.NODOMAIN + '/shipApi/jxsUser/updStore';
    return wxRequest.postRequest(url, data);
}

/**
 * 修改账号的密码  
 * */
function updatePassword(data) {
    var url = config.NODOMAIN + '/shipApi/jxsUser/updatepassword';
    return wxRequest.postRequest(url, data);
}

/**
 * 获取所有经销商
 * */
function getDealerList(data) {
    var url = config.NODOMAIN + '/shipApi/jxsUser/getSubJxsUserInfo';
    return wxRequest.getRequest(url, data);
}

module.exports = {
    getStoreList,
    saveStoreEmployee,
    getStoreUser,
    getUserInfo,
    updateUserStatus,
    saveStore,
    updateStore,
    updatePassword,
    getDealerList
}
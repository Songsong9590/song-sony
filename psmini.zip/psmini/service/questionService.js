const wxRequest = require('../api/wxRequest.js');
const config = require('../utils/config.js');

/**
 * getRequest:     get
 * putRequest:     put
 * postRequest     post
 */

/**
 * 获取全部培训内容
 * */
function  getAllTrainningInfo(data) {
    var url = config.NODOMAIN + '/shipApi/jxsUser/getAllTrainningInfo';
    return wxRequest.getRequest(url, data);
}

/**
 * 获取指定培训介绍内容
 * */
function getTheTrainningDetail(data) {
    var url = config.NODOMAIN + '/shipApi/jxsUser/getTheTrainningDetail';
    return wxRequest.getRequest(url, data);
}

/**
 * 获取指定培训的全部测验内容
 * */
function getTheExaminationDetail(data) {
    var url = config.NODOMAIN + '/shipApi/jxsUser/getTheExaminationDetail';
    return wxRequest.getRequest(url, data);
}

/**
 * 提交试卷并计算分数
 * */
function submitTheExam(data) {
    var url = config.NODOMAIN + '/shipApi/jxsUser/submitTheExam';
    return wxRequest.postRequest(url, data);
}

/**
 * 获取指定用户测验结果
 * */
function getAllExamResults(data) {
    var url = config.NODOMAIN + '/shipApi/jxsUser/getAllExamResults';
    return wxRequest.getRequest(url, data);
}

module.exports = {
  getAllTrainningInfo,
  getTheTrainningDetail,
  getTheExaminationDetail,
  submitTheExam,
  getAllExamResults
}
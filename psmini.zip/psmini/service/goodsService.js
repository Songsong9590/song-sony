/**
 * 登录接口
 * 
 * 数据层
 * 专注提供数据到view层
 * 上册 => api层 服务端接口请求，接口状态管理
 * 下层 => view层 业务逻辑
 * 
 */
const wxRequest = require('../api/wxRequest.js');
const config = require('../utils/config.js');

/**
 * getRequest:     get
 * putRequest:     put
 * postRequest     post
 */

/**
 * 获取所有商品类型
 * */
function getSpTypeAll(data) {
    var url = config.DOMAIN + '/shipApi/sp/getSpTypeAll';
    return wxRequest.getRequest(url, data);
}
/**
 * 获取所有商品
 * */
function getSpAll(data) {
    var url = config.DOMAIN + '/shipApi/sp/getSpAll';
    return wxRequest.getRequest(url, data);
}
/**
 * 获取热销排行商品
 * */
function getSalesVolumeRanking(data) {
    var url = config.DOMAIN + '/shipApi/sp/salesVolumeRanking';
    return wxRequest.getRequest(url, data);
}
/**
 * 获取商品详情
 * */
function getSpDetails(data) {
    var url = config.DOMAIN + '/shipApi/sp/getSpDetails';
    return wxRequest.getRequest(url, data);
}

/**
 * 获取商品信息
 * 根据P码或者69码查询商品信息
 * @param PM string
 * */
function getSpByPM(data) {
    var url = config.DOMAIN + '/shipApi/sp/getSpByPM';
    return wxRequest.getRequest(url, data);
}

/**
 * 库存入库相关接口
 * 生成库存调拨单
 * @param userid string
 * @param spList string
 * @param storeid string
 * */
function saveallotKc(data) {
    var url = config.NODOMAIN + '/shipApi/spkc/allotKc';
    return wxRequest.postRequest(url, data);
}

/**
 * 库存入库相关接口
 * 获取库存调拨单
 * @param userid string
 * */
function getAllotKcList(data) {
    var url = config.NODOMAIN + '/shipApi/spkc/getAllotKcList';
    return wxRequest.getRequest(url, data);
}

/**
 * 库存入库相关接口
 * 审核--确认通过
 * @param userid string
 * */
function saveSuccess(data) {
    var url = config.NODOMAIN + '/shipApi/spkc/shsuccess';
    return wxRequest.postRequest(url, data);
}

/**
 * 库存入库相关接口
 * 审核--拒绝通过
 * @param userid string
 * */
function saveFail(data) {
    var url = config.NODOMAIN + '/shipApi/spkc/shfail';
    return wxRequest.postRequest(url, data);
}

/**
 * 获取库存列表
 * @param userid string
 * @param storeid string
 * */
function getAllStockList(data) {
    var url = config.NODOMAIN + '/shipApi/spkc/getSpKcList';
    return wxRequest.getRequest(url, data);
}

/**
 * 获取库存列表
 * @param userid string
 * @param storeid string
 * */
function getAllotZbKcList(data) {
    var url = config.NODOMAIN + '/shipApi/spkc/getAllotZbKcList';
    return wxRequest.getRequest(url, data);
}

/**
 * 库存入库相关接口
 * 生成库存调拨单
 * @param userid string
 * @param spList string
 * @param storeid string
 * */
function saveallotZbKc(data) {
    var url = config.NODOMAIN + '/shipApi/spkc/allotZbKc';
    return wxRequest.postRequest(url, data);
}

/**
 * 获取库存列表
 * @param userid string
 * @param storeid string
 * */
function getZbSpKcList(data) {
    var url = config.NODOMAIN + '/shipApi/spkc/getZbSpKcList';
    return wxRequest.getRequest(url, data);
}

module.exports = {
    getSpTypeAll,
    getSpAll,
    getSpDetails,
    getSalesVolumeRanking,
    getSpByPM,
    saveallotKc,
    getAllotKcList,
    saveSuccess,
    saveFail,
    getAllStockList,
    getAllotZbKcList,
    saveallotZbKc,
    getZbSpKcList
}
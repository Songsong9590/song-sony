/**
 * 登录接口
 * 
 * 数据层
 * 专注提供数据到view层
 * 上册 => api层 服务端接口请求，接口状态管理
 * 下层 => view层 业务逻辑
 * 
 */
const wxRequest = require('../api/wxRequest.js');
const config = require('../utils/config.js');

/**
 * getRequest:     get
 * putRequest:     put
 * postRequest     post
 */

/**
 * /shipApi/task/taskList
任务列表
 * */
function OffTaskList(data) {
    var url = config.DOMAIN + '/shipApi/task/taskList';
    data.original = config.ORIGINAL
    return wxRequest.postRequest(url, data);
}
/**
 * /shipApi/task/details
详情
 * */
function OffTaskDetails(data) {
    var url = config.DOMAIN + '/shipApi/task/details';
    return wxRequest.postRequest(url, data);
}
/**
 * /shipApi/task/taskQrcode
海报二维码
 * */
function OffTaskQrcode(data) {
    var url = config.DOMAIN + '/shipApi/task/taskQrcode';
    return wxRequest.postRequest(url, data);
}

/**
 * shipApi/spkc/getAllNotice
公告列表
 * */
function getAllNotice(data) {
    var url = config.DOMAIN + '/shipApi/spkc/getAllNotice';
    return wxRequest.getRequest(url, data);
}

/**
 * shipApi/spkc/getNoticeDetails
公告内容
 * */
function getNoticeDetails(data) {
    var url = config.DOMAIN + '/shipApi/spkc/getNoticeDetails';
    return wxRequest.getRequest(url, data);
}
module.exports = {
    OffTaskList,
    OffTaskDetails,
    OffTaskQrcode,
    getAllNotice,
    getNoticeDetails
}
/**
 * 
 * 数据层
 * 专注提供数据到view层
 * 上册 => api层 服务端接口请求，接口状态管理
 * 下层 => view层 业务逻辑
 * 
 */
const wxRequest = require('../api/wxRequest.js');
const config = require('../utils/config.js');



/**
 * getRequest:     get
 * putRequest:     put
 * postRequest     post
 */



/**
 * 删除用户收货地址
/api/yhdz/deleteDz
id  地址id
 * */
function deleteDz(data) {
    var url = config.DOMAIN + '/shipApi/yhdz/deleteDz';

    return wxRequest.getRequest(url, data);
}

/**获取用户收货地址列表
 * /api/yhdz/getDzAll
 * isDefault      加此参数返回默认地址且 必须传 1
 * */

function getDzAll(data) {
    var url = config.DOMAIN + '/shipApi/yhdz/getDzAll';
    return wxRequest.getRequest(url, data);
}

/**
 * 获取用户收货地址详情
 *api/yhdz/getDzDetails
 * id       地址id
 * */

function getDzDetails(data) {
    var url = config.DOMAIN + '/shipApi/yhdz/getDzDetails';
    return wxRequest.getRequest(url, data);
}

/**
 * 保存或修改用户收货地址
 *api/yhdz/saveDz
 * address        详细地址
 * area           地区
 * bq             标签
 * city           城市
 * id             地址id
 * isDefault             默认地址 填1
 * name              姓名
 * phone             手机号
 * province             省
 * sex              性别1男2女
 * */

function saveDz(data) {
    var url = config.DOMAIN + '/shipApi/yhdz/saveDz';
    return wxRequest.postRequest(url, data);
}

// 支付
function pay(data) {
    var url = config.DOMAIN + '/shipApi/wx/pay';
    data.original = config.ORIGINAL
    return wxRequest.postListRequest(url, data);
    // return wxRequest.postRequest(url, data); 

}

// 个人信息
function getUserInfo(data) {
    var url = config.DOMAIN + '/common/khxx/userInfo';
    return wxRequest.getRequest(url, data);

}


// 添加formid
// function formId(id) {
//     var url = config.DOMAIN + '/common/khxx/formId';
//     var data={
//         formId: id
//     }
//     return wxRequest.postRequest(url, data);
// }



// 获取banner
function getBanner(data) {
    var url = config.DOMAIN + '/shipApi/banner/banner';
    return wxRequest.getRequest(url, data);
}


// 餐厅预订接口
// 餐厅预订列表
function getCtydList(data) {
    var url = config.DOMAIN + '/shipApi/ctyd/ctydList';
    return wxRequest.getRequest(url, data);

}

// 获取餐厅预订详情
function getCtydDetail(data) {
    var url = config.DOMAIN + '/shipApi/ctyd/getCtyd';
    return wxRequest.getRequest(url, data);

}
// 取消餐厅预订
function qxCtyd(data) {
    var url = config.DOMAIN + '/shipApi/ctyd/qxCtyd';
    return wxRequest.getRequest(url, data);

}
// 保存餐厅预订
function saveCtyd(data) {
    var url = config.DOMAIN + '/shipApi/ctyd/saveCtyd';
    return wxRequest.postRequest(url, data);

}

// 餐厅预订 发送验证码
function sendRegisterSms(data) {
    var url = config.DOMAIN + '/shipApi/ctyd/send-register-sms';
    return wxRequest.postRequest(url, data);

}


// 餐厅预订 验证手机号
function verifyRegisterSms(data) {
    var url = config.DOMAIN + '/shipApi/ctyd/verify-register-sms';
    return wxRequest.postRequest(url, data);
}

// 获取我的客户列表
function getKhxxPropagate(data) {
    var url = config.DOMAIN + '/common/khxx/propagate';
    return wxRequest.getRequest(url, data);
}


// 获取我的客户列表
function getStoreLsit(data) {
    var url = config.DOMAIN + '/shipApi/store/getStoreLsit';
    return wxRequest.getRequest(url, data);
}

// 获取我的订单数
function getOrderCount(data) {
    var url = config.DOMAIN + '/shipApi/order/getOrderCount';
    return wxRequest.getRequest(url, data);
}


/*产品注册*/
/*
 注册  
    authNo *    认证号
    phone *     手机号
    produceCode *    产品号
*/
function deuterCheckreg(data) {
    var url = config.DOMAIN + '/shipApi/mugaodi/reg/checkreg';
    return wxRequest.postRequest(url, data);
}
/*
    查看注册历史详情  返回regStatus注册状态 1 未激活 2 已激活 3 已注册 4 已注销
    id *    历史记录id
    phone *     手机号
*/
function deuterRegFind(data) {
    var url = config.DOMAIN + '/shipApi/mugaodi/reg/find';
    return wxRequest.getRequest(url, data);
}
/*
     查看已注册码
*/
function deuterRegFindAllCode(data) {
    var url = config.DOMAIN + '/shipApi/mugaodi/reg/findAllCode';
    return wxRequest.getRequest(url, data);
}
/*
     注册礼列表
*/
function deuterRegFindAllGift(data) {
    var url = config.DOMAIN + '/shipApi/mugaodi/reg/findAllGift';
    return wxRequest.getRequest(url, data);
}

/*
    电子卡信息 
    address  *    地址
    birthday  *     出生年月
    chineseName  *    姓名（中文）
    city   *    城市
    email   *    邮箱
    headimgurl   *    头像
    phone   *    手机
    phoneticName   *   姓名(拼音)
*/
function deuterRegElectronic(data) {
    var url = config.DOMAIN + '/shipApi/mugaodi/reg/reg_electronic';
    return wxRequest.postRequest(url, data);
}

/*
     领取注册礼
    id  *    记录id
    reggift_id  *     注册礼id
*/
function deuterRegGift(data) {
    var url = config.DOMAIN + '/shipApi/mugaodi/reg/reg_gift';
    return wxRequest.postRequest(url, data);
}

/*
   
    注册成功跳转页面 返回regStatus注册状态 1 未激活 2 已激活 3 已注册 4 已注销
    reggift_id  *     注册礼id
*/
function deuterRegSuccess(data) {
    var url = config.DOMAIN + '/shipApi/mugaodi/reg/reg_success';
    return wxRequest.postRequest(url, data);
}
/*
    扫描二维码
    urlResult   
*/
function deuterRegScan(data) {
    var url = config.DOMAIN + '/shipApi/mugaodi/reg/scan';
    return wxRequest.postRequest(url, data);
}
/*
        判断手机号是否登记过
*/
function deuterRegCheckPhone(data) {
    var url = config.DOMAIN + '/shipApi/mugaodi/reg/checkPhone';
    return wxRequest.postRequest(url, data);
}


// 注册礼
// 新增页面
/*
获取客服 读取businessCard
*/
function getQrcodeImg(data) {
    var url = config.DOMAIN + '/shipApi/mugaodi/reg/getQrcode';
    return wxRequest.getRequest(url, data);
}
// 使用说明列表 type1 pdf 2 视频    
// reg_id    注册码id
function mugaodiregfindPdf(data) {
    var url = config.DOMAIN + '/shipApi/mugaodi/reg/findPdf';
    return wxRequest.getRequest(url, data);
}
// 查看问题
// reg_id    注册码id
function mugaodiregfindProbleAnswer(data) {
    var url = config.DOMAIN + '/shipApi/mugaodi/reg/findProbleAnswer';
    return wxRequest.getRequest(url, data);
}

// 查看售后服务记录列表 zt 1|已申请 2|已同意 3|未同意 4|已完成
function mugaodiregfindAllApply(data) {
    var url = config.DOMAIN + '/shipApi/mugaodi/reg/findAllApply';
    return wxRequest.getRequest(url, data);
}
// 获取售后问卷    id  售后服务id
function mugaodiregfindApply(data) {
    var url = config.DOMAIN + '/shipApi/mugaodi/reg/findApply';
    return wxRequest.getRequest(url, data);
}
/*
提交问卷 records:List<NewExamRecord> 对象中的参数如下
*/
function newexamAnswer(data) {
    var url = config.DOMAIN + '/shipApi/mugaodi/reg/answer';
    return wxRequest.postListRequest(url, data);
}

// 相关产品列表
// page 
// size
// proRegId  *   产品id
// type *   类型
function mugaodiregproReg(data) {
    var url = config.DOMAIN + '/shipApi/mugaodi/reg/proReg';
    return wxRequest.getRequest(url, data);
}


// 首页

// 查看标签
function mugaodiregfindTag(data) {
    var url = config.DOMAIN + '/shipApi/mugaodi/reg/findTag';
    return wxRequest.getRequest(url, data);
}
/**
 参数：configkey 参数值platform_id get请求
configValue 获取的id值

 * */
function regsaveOrder(data) {
    var url = config.DOMAIN + '/shipApi/mugaodi/reg/saveOrder';
    return wxRequest.postRequest(url, data);
}
// 根据标签查询新闻资讯（主页）
function mugaodiregfindZxByTag(data) {
    var url = config.DOMAIN + '/shipApi/mugaodi/reg/findZxByTag';
    return wxRequest.getRequest(url, data);
}

// （主页）tab列表
// 参数 original
function getMenuList(data) {
    var url = config.DOMAIN + '/shipApi/auth/getMenuList';
    var data = {
        original: config.ORIGINAL
    }
    return wxRequest.getRequest(url, data);
}

// 首页新闻详情

function zxwordSmallDetails(data) {
    var url = config.DOMAIN + '/shipApi/zx/wordSmallDetails';
    return wxRequest.postRequest(url, data);
}


// -------------------------------------------------------------------------定制申请

/*1. 定制申请(表单回显时需要传线索id)
请求方式：GET
参数：clueid  线索id(申请不需要传)
*/
function cluegetExam(data) {
    var url = config.DOMAIN + '/shipApi/clue/getExam';
    return wxRequest.getRequest(url, data);
}

/*2. 提交表单
请求方式：GET
参数：clueid  线索id(申请不需要传)
*/
function clueanswer(data) {
    var url = config.DOMAIN + '/shipApi/clue/answer';
    return wxRequest.postListRequest(url, data);
}

/*3. 查询线索(电商端) 定制申请
 */
function cluefindListkh(data) {
    var url = config.DOMAIN + '/shipApi/clue/findList_kh';
    return wxRequest.getRequest(url, data);
}

/*5. 线索详情
 */
function clueget(data) {
    var url = config.DOMAIN + '/shipApi/clue/get';
    return wxRequest.getRequest(url, data);
}

// 


/* 获取系统配置的参数
参数 key
需要传的值advance_charge  查询预付款
*/
function projectConfig(data) {
    var url = config.DOMAIN + '/shipApi/projectConfig/getConfig';
    return wxRequest.getRequest(url, data);
}

/* 9. 查看线索成员
参数：
clueId  组织id
*/
function cluefindListMember(data) {
    var url = config.DOMAIN + '/shipApi/clue/findList_member';
    return wxRequest.getRequest(url, data);
}


/*  查看线索日志 
请求方式：GET
参数：
clueid  线索id
page 
size
*/
function clueFindListClueLog(data) {
    var url = config.DOMAIN + '/shipApi/clue/findList_clueLog';
    return wxRequest.getRequest(url, data);
}

/* 14. 添加记录
参数：
clueId  线索id
content 内容
imgUrl           图片
videoUrl	视频
voiceUrl	音频
link		链接
linkName 	链接名称
linkCover	链接封面
*/
function communicationAdd(data) {
    var url = config.DOMAIN + '/shipApi/communication/issueOpinion';
    return wxRequest.postRequest(url, data);
}

// ------------------------------------------------------------------------------------线索描述
/* 15. 描述删除
参数：
descriptionId  描述id
*/
function communicationdescriptionDelete(data) {
    var url = config.DOMAIN + '/shipApi/communication/descriptionDelete';
    return wxRequest.postRequest(url, data);
}

/* 16. 查看详情 描述记录详情
接口：
请求方式：GET
参数：
descriptionId  描述id
*/
function communicationdescriptionDetails(data) {
    var url = config.DOMAIN + '/shipApi/communication/descriptionDetails';
    return wxRequest.getRequest(url, data);
}


/* 17. 给描述添加评论
请求方式：POST
参数：
descriptionId  描述id  或者评论id
content 评论内容
parentId 需要回复的描述id

*/
function communicationaddDescriptionComment(data) {
    var url = config.DOMAIN + '/shipApi/communication/addDescriptionComment';
    return wxRequest.postRequest(url, data);
}

/*18. 删除描述的评论
参数：
descriptionCommentId  评论的id
*/
function communicationdescriptionCommentDelete(data) {
    var url = config.DOMAIN + '/shipApi/communication/descriptionCommentDelete';
    return wxRequest.postRequest(url, data);
}
/*19. 点赞
参数：
type  类型id  1 描述点赞 2评论点赞
associationId  相关id

*/
function communicationfabulous(data) {
    var url = config.DOMAIN + '/shipApi/communication/fabulous';
    return wxRequest.postRequest(url, data);
}


/*20. 描述详情评论列表
参数：
page
size
associationId  相关id 
*/
function communicationdescriptionCommentList(data) {
    var url = config.DOMAIN + '/shipApi/communication/descriptionCommentList';
    return wxRequest.getRequest(url, data);
}



/**
 * 
  收藏或取消
 * */
function collectionScOrQx (data) {
    var url = config.DOMAIN + '/shipApi/collection/scOrQx';
    return wxRequest.postRequest(url, data);
  }

module.exports = {
    deleteDz,
    getDzAll,
    getDzDetails,
    saveDz,
    pay,
    getUserInfo,
    // formId,
    getBanner,
    getCtydList,
    getCtydDetail,
    qxCtyd,
    saveCtyd,
    sendRegisterSms,
    verifyRegisterSms,
    getKhxxPropagate,
    getStoreLsit,
    getOrderCount,


    // 注册产品
    deuterCheckreg,
    deuterRegFind,
    deuterRegFindAllCode,
    deuterRegFindAllGift,
    deuterRegElectronic,
    deuterRegGift,
    deuterRegSuccess,
    deuterRegScan,
    deuterRegCheckPhone,


    //注册礼 新增接口
    getQrcodeImg,
    mugaodiregfindPdf,
    mugaodiregfindProbleAnswer,
    mugaodiregfindAllApply,
    mugaodiregfindApply,
    newexamAnswer,
    mugaodiregproReg,

    mugaodiregfindTag,
    regsaveOrder,
    mugaodiregfindZxByTag,
    getMenuList,
    zxwordSmallDetails,


    // 定制申请
    cluegetExam,
    clueanswer,
    cluefindListkh,
    clueget,
    projectConfig,
    cluefindListMember,
    clueFindListClueLog,

    //线索描述
    communicationAdd,
    communicationdescriptionDelete,
    communicationdescriptionDetails,
    communicationaddDescriptionComment,
    communicationdescriptionCommentDelete,
    communicationfabulous,
    communicationdescriptionCommentList,

    // 收藏
    collectionScOrQx
}
const app = getApp()
const employeeService = require("../../service/employeeService.js");
const common = require("../../assets/js/common.js");

Page({
  data: {
    userInfo:{},
    oldStatus:'password',
    newStatus:'password',
    confirmStatus:'password',
    newPassword:"",
    confirmPassword:"",
  },
  onLoad() {
    let jxsUserId = wx.getStorageSync('jxsUserId');
    employeeService.getUserInfo({"userid":jxsUserId}).then(res => {
      if (res.data.code == 200) {
        var result = {
          "account":res.data.data.account,
          "mobile":res.data.data.phone,
          "password":res.data.data.password,
        }
        this.setData({
          userInfo:result,
        })
      } else {
          common.showToast(res.data.message)
      }
    })
  },
  showOldPwd:function(){
    this.setData({
      oldStatus:this.data.oldStatus == 'text'?'password':'text'
    })
  },
  showNewPwd:function(){
    this.setData({
      newStatus:this.data.newStatus == 'text'?'password':'text'
    })
  },
  showConfirmPwd:function(){
    this.setData({
      confirmStatus:this.data.confirmStatus == 'text'?'password':'text'
    })
  },
  bindSubmit(e) {
    let params = e.detail.value;
    let isError = true;
    if(!params.password){
      isError = false;
      common.showToast("请填写旧密码")
    }
    if(!params.newpassword){
      isError = false;
      common.showToast("请填写新密码密码")
    }
    if(!params.confirmpassword){
      isError = false;
      common.showToast("请填写确认密码")
    }
    if (params.newpassword != params.confirmpassword){
      isError = false;
      common.showToast("请确保新密码一致")
    }
    console.log(params)
    if  (!isError){return false;}
    let data = {
      "account":"fanxingyu",
      "password":params.password,
      "newpassword":params.newpassword,
    }
    wx.showLoading({
      title: '数据处理中，请稍候...'
    })
    this.updatePassword(data);
  },
  updatePassword:function(params){
    employeeService.updatePassword(params).then(res => {
      if (res.data.code == 200) {
        wx.hideLoading()
        common.showToast('修改密码成功!即将跳转到登录页面')
        setTimeout(function () {
          //要延时执行的代码
            wx.reLaunch({
              url: "../login/login"
            })
        }, 2000) //延迟时间
      } else {
          common.showToast(res.data.message)
      }
    })
  }
})

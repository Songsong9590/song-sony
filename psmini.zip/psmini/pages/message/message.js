
const app = getApp()
const salesService = require("../../service/salesService.js");
const employeeService = require("../../service/employeeService.js");
const goodsService = require("../../service/goodsService.js");
const common = require("../../assets/js/common.js");
const config = require('../../utils/config.js');

Page({
  data: {
    count:0,
    currentTab: 0,
    currentType: 0,
    params:{"id":"","user_id":"","shstatus":""},
    salesType:{'pending':"待审核","pass":"已审核","fail":"审核失败","pending_again":"重审中"},
    stockType:["未审核","成功","拒绝"],
    statusType:["待审核","正常","异常"],
    roleType:["未知","总部超管","经销商管理员","门店店长","店员"],
    salesWhere:["","pending","pass"],
    stockWhere:["","0","1"],
    urls:{"stock":"../stock/info","sales":"../sales/sales_info","employee":"../employee/info"},
    page:1
  },
  onLoad() {
    this.setData({
      "params.user_id":wx.getStorageSync('jxsUserId'),
      roleid : wx.getStorageSync('roleid')
    })
  },
  onShow() {
    let that = this
    if (app.globalData.status != null) {
      if (app.globalData.status == '0'){
        that.getSalesList([],{"user_id":that.data.params.user_id,"id":"","shstatus":"pending","page":that.data.page})
      } else if(app.globalData.status == '1'){
        that.getStockList({"userid":that.data.params.user_id,"shstatus":"0","allotkcid":''})
      } else if(app.globalData.status == '2'){
        that.getEmployeeList({"userid":that.data.params.user_id,"shstatus":"0","storeid":""})
      }
      that.setData({
        currentTab: 1,
        currentType: app.globalData.status
       })
    } else {
      this.getSalesList([],this.data.params)
    }
  },
   //滑动切换
 swiperTab: function (e) {
  var that = this;
  that.setData({
   currentTab: e.detail.current
  });
 },
 //点击切换
 clickTab: function (e) {
  var that = this;
  if (that.data.currentType == '0'){
    that.getSalesList([],{"user_id":that.data.params.user_id,"id":"","shstatus":that.data.salesWhere[e.target.dataset.current],"page":that.data.page})
  } else if(that.data.currentType == '1'){
    that.getStockList({"userid":that.data.params.user_id,"shstatus":that.data.stockWhere[e.target.dataset.current],"allotkcid":''})
  } else if(that.data.currentType == '2'){
    that.getEmployeeList({"userid":that.data.params.user_id,"shstatus":that.data.stockWhere[e.target.dataset.current],"storeid":""})
  }
   that.setData({
    currentTab: e.target.dataset.current
   })
  this.alertMessage()
 },
  //点击切换
  clickType: function (e) {
    var that = this;
    if (e.target.dataset.current == '0'){
      that.getSalesList([],{"user_id":that.data.params.user_id,"id":"","shstatus":"","page":that.data.page})
    } else if(e.target.dataset.current == '1'){
      that.getStockList({"userid":that.data.params.user_id,"shstatus":"","allotkcid":''})
    } else if(e.target.dataset.current == '2'){
      that.getEmployeeList({"userid":that.data.params.user_id,"shstatus":"","storeid":""})
    }
     that.setData({
      currentType: e.target.dataset.current,
      currentTab:0
     })
    this.alertMessage()

   },
   getSalesList:function(list = [],params= {}) {
    salesService.getOrderList(params).then(res => {
      if (res.data.code == 200) {
        let lists = res.data.data.list;
        if (lists.length == 0) {
          this.setData({
            isloading:true,
            data:list?list:[]
        })
          wx.showToast({
            title:'没有待审批数据',
            icon:'none'
          })
          return false;
        }
        for(var i in lists) {
          var data = lists[i].spDesc;
          let name = '';
          for(var s in data) {
            name += data[s].spXx.spmc + ' (' + data[s].inputNum + ') '
          }
          list.push({
            active:"sales",
            name: name,
            id:lists[i].id,
            status:lists[i].shstatus,
            statusName:this.data.salesType[lists[i].shstatus],
            date:lists[i].insertTime,
            actionName:lists[i].jxsUser.name,
            dealer:lists[i].jxsUserAdmin.name?lists[i].jxsUserAdmin.name:"",
            storeName:lists[i].store.name?lists[i].store.name:"",
          })
          wx.hideLoading();
        }
        this.setData({
          data:list,
          count:res.data.data.count,
          page:params.page?params.page:1
        })
      } else {
          common.showToast(res.data.message)
      }
    })
  },
  getStockList:function(params= {}){
    let list = [];
    goodsService.getAllotKcList(params).then(res => {
      if (res.data.code == 200) {
        let lists = res.data.data;
        for (var i=0;i<lists.length;i++){ 
          var data = lists[i].allotKcDesc;
          let name = '';
          for(var s in data) {
            name += data[s].spXx.spmc + ' (' + data[s].kc + ') '
          }
          list.push({
            active:"stock",
            name: name,
            id:lists[i].id,
            status:lists[i].shstatus,
            statusName:this.data.stockType[lists[i].shstatus],
            date:lists[i].createDate,
            dealer:lists[i].jxsUser.name?lists[i].jxsUser.name:"",
            storeName:lists[i].store.name,
          })
        }
        this.setData({
          data:list
        })
      } else {
          common.showToast(res.data.message)
      }
    })
  },
  getEmployeeList:function(params= {}){
    let list = []; 
    employeeService.getStoreUser(params).then(res => {
      if (res.data.code == 200) {
        let employees = res.data.data;
        if (employees.length > 0) {
          for (var i=0;i<employees.length;i++){ 
            list.push({
              active:"employee",
              name:employees[i].jxsUser.name,
              role:this.data.roleType[employees[i].jxsUser.roleid],
              mobile: employees[i].jxsUser.phone?employees[i].jxsUser.phone:"",
              status: employees[i].jxsUser.shstatus,
              statusName: this.data.statusType[employees[i].jxsUser.shstatus],
              dealer:employees[i].jxsUserAdmin.name?employees[i].jxsUserAdmin.name:"",
              image : employees[i].jxsUser.headportrait?config.NODOMAIN + employees[i].jxsUser.headportrait:"https://sony.zikudata.com/static/avator.jpg",
              id:employees[i].jxsUser.id,
              account:employees[i].jxsUser.account,
              storeName:employees[i].store.name,
            })
          }
        }
        this.setData({
          data:list
        })
      } else {
          common.showToast(res.data.message)
      }
    })
  },
  bindToInfo:function(e){
    let active = e.currentTarget.dataset.active
    let url = this.data.urls[active];
    switch(active) {
      case "sales":
        url += '?orderId='+e.currentTarget.dataset.id+"&status="+"1"
        break;
      case "stock":
        url += '?allotkcid='+e.currentTarget.dataset.id+"&status="+"1"
        break;
      case "employee":
        url += "?status="+"1"
        wx.setStorageSync('employeeInfo',this.data.data[e.currentTarget.dataset.index]);
        break;
    }
    wx.navigateTo({
      url: url
    })
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this;
    var pageSize = that.data.count/10;
    if(pageSize <= that.data.page){
      wx.showToast({
        title: '没有更多数据了',
        icon:'none'
      })
      return false;
    }
    switch(that.data.currentType){
      case "0":
        wx.showLoading({
          title: '加载中',//加载转圈显示
        });
        var params = {"user_id":that.data.params.user_id,"id":"","shstatus":that.data.salesWhere[that.data.currentTab],"page":that.data.page+1}
        that.getSalesList(that.data.data,params)
        break;
    }
  },
  alertMessage:function(){
    let roleid = wx.getStorageSync('roleid')
    if(!app.globalData.isAuthorize && roleid == 2){
        wx.requestSubscribeMessage({
          tmplIds: ['7jafeoAsuOxJe5J1HM_X8ASS3GdLwcPsvz4aJwyioQQ'],
          success (res) {
            app.globalData.isAuthorize = true
          },
        })
    }
  }
})

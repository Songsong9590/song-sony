// index.js
// 获取应用实例
const app = getApp()
const employeeService = require("../../service/employeeService.js");
const common = require("../../assets/js/common.js");

Page({
  data: {},
  onLoad() {
    let storeInfo = wx.getStorageSync('storeInfo');    
    this.setData({
      storeInfo:storeInfo
    })
  },
  bindSubmit(e) {
    let params = e.detail.value;
    if(!params.storeName || !params.address || !params.opentime ){
      common.showToast("请填写完整信息！")
    }
    wx.showLoading({
      title: '数据处理中，请稍候...'
    })
    params.userid = wx.getStorageSync('jxsUserId')
    params.storeId = this.data.storeInfo.id
    employeeService.updateStore(params).then(res => {
      if (res.data.code == 200) {
        wx.hideLoading()
        common.showToast('修改成功！')
        setTimeout(function () {
          //要延时执行的代码
          wx.navigateTo({
            url: '../employee/store'
          })
        }, 2000) //延迟时间
      } else {
          common.showToast(res.data.message)
      }
    })
  },
})

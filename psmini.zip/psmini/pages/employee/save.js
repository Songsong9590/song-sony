// index.js
// 获取应用实例
const app = getApp()
const employeeService = require("../../service/employeeService.js");
const common = require("../../assets/js/common.js");

Page({
  data: {
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    roleType: [{"name":'门店店长',"value":'3'}, {"name":'店员',"value":'4'}],
    sexType: [{"name":'男',"value":'1'}, {"name":'女',"value":'2'}],
    roleIndex:0,
    sexIndex:0,
    username:null,
    password:'123456',
    stores:[],
    format:{
      'sex':'',
      'account':null,
      'name':null,
      'password':'',
      'roleId':'',
      'storeId':'',
    }
  },
  bindRoleChange: function(e) {
    console.log(e);
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      'format.roleId': this.data.roleType[e.detail.value].value,
      roleIndex:e.detail.value
    })
  },
  bindSexChange: function(e) {
    console.log(e);
    console.log('picker发送选择改变，携带值为', this.data.sexType[e.detail.value].value)
    this.setData({
      'format.sex': this.data.sexType[e.detail.value].value,
      sexIndex:e.detail.value
    })
  },
  onLoad() {
    let storeInfo = wx.getStorageSync('storeInfo');
    if (storeInfo) {
      this.setData({
        stores:storeInfo,
        'format.storeId': storeInfo.id,
        'format.roleId': this.data.roleType[this.data.roleIndex].value,
        'format.sex': this.data.sexType[this.data.sexIndex].value,
      })
    }
  },
  accountInput:function(e)
  {
    this.setData({
      'format.account': e.detail.value
    })
  },
  nameInput:function(e)
  {
    this.setData({
      'format.name': e.detail.value
    })
  },
  passwordInput:function(e)
  {
    this.setData({
      'format.password': e.detail.value
    })
  },
  bindSubmit() {
    if(!this.data.format.name || !this.data.format.account || !this.data.format.password){
      common.showToast('员工信息不完整！');
      return false;
    }
    wx.showLoading({
      title: '数据处理中，请稍候...'
    })
    employeeService.saveStoreEmployee(this.data.format).then(res => {
      if (res.data.code == 200) {
        wx.hideLoading()
        common.showToast('创建成功！')
        setTimeout(function () {
          //要延时执行的代码
          wx.navigateTo({
            url: '../employee/list'
          })
        }, 2000) //延迟时间
      } else {
          common.showToast(res.data.message)
      }
    })
  },
})

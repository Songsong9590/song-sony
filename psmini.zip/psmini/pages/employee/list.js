// index.js
// 获取应用实例
const app = getApp();
const employeeService = require("../../service/employeeService.js");
const common = require("../../assets/js/common.js");
const config = require('../../utils/config.js');

Page({
  data: {
    storeInfo:{},
    roleType:["未知","总部超管","经销商管理员","门店店长","店员"],
    statusType:["待审核","正常","异常"],
    employeeList:[],
    usernamee:""
  },
  onLoad() {
    let storeInfo = wx.getStorageSync('storeInfo');  
    this.getEmployeeList({"storeid":storeInfo.id});      
    this.setData({
      storeInfo:storeInfo,
      roleid:wx.getStorageSync('roleid')
    })
  },
  getEmployeeList:function(params= {}){
    let list = []; 
    employeeService.getStoreUser(params).then(res => {
      if (res.data.code == 200) {
        let employees = res.data.data;
        if (employees.length > 0) {
          for (var i=0;i<employees.length;i++){ 
            list.push({
              name:employees[i].jxsUser.name,
              role:this.data.roleType[employees[i].jxsUser.roleid],
              mobile: employees[i].jxsUser.phone,
              status: employees[i].jxsUser.shstatus,
              statusName: this.data.statusType[employees[i].jxsUser.shstatus],
              image : employees[i].jxsUser.headportrait?config.NODOMAIN + employees[i].jxsUser.headportrait:"https://sony.zikudata.com/static/avator.jpg",
              id:employees[i].jxsUser.id,
              account:employees[i].jxsUser.account,
            })
          }
        }
        this.setData({
          employeeList:list
        })
      } else {
          common.showToast(res.data.message)
      }
    })
  },
  searchEmployee:function(e){
    console.log(e)
    this.getEmployeeList({"storeid":this.data.storeInfo.id,"dyName":e.detail.value}); 
  },
  bindEmployeeSave:function(){
    wx.navigateTo({
      url: '../employee/save'
    })
  },
  bindEmployeeInfo:function(e){
    wx.setStorageSync('employeeInfo',this.data.employeeList[e.currentTarget.dataset.index]);
    wx.navigateTo({
      url: '../employee/info'
    })
  },
  bindStoreUpdate:function(){
    console.log(this.data.storeInfo)
    wx.navigateTo({
      url: '../employee/store_update?storeid='+this.data.storeInfo.id
    })
  }
})

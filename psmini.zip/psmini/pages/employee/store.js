// index.js
// 获取应用实例
const app = getApp()
const employeeService = require("../../service/employeeService.js");
const common = require("../../assets/js/common.js");
const config = require('../../utils/config.js');

Page({
  data: {
    storeList:[],
    roleid:""
  },
  onLoad() {
    let list = [];
    let jxsUserId = wx.getStorageSync('jxsUserId');
    this.setData({
      roleid:wx.getStorageSync('roleid')
    })
    employeeService.getStoreList({"jxsUserId":jxsUserId}).then(res => {
      if (res.data.code == 200) {
        let stores = res.data.data;
        for (var i=0;i<stores.length;i++){ 
          list.push({
            name:stores[i].store.name,
            address:stores[i].store.address,
            date: stores[i].store.opentime,
            num: stores[i].store.usernum,
            dealer: stores[i].jxsUser.name,
            image : stores[i].store.img?config.NODOMAIN + stores[i].store.img:"https://sony.zikudata.com/static/index9.png",
            id:stores[i].store.id
          })
          this.setData({
            storeList:list
          })
        }
      } else {
          common.showToast(res.data.message)
      }
  })
  },
   bindToEmployee: function (e) {
     if (e.currentTarget.dataset.index >= 0) {
       let index = e.currentTarget.dataset.index;
      wx.setStorageSync('storeInfo',this.data.storeList[index]);
      wx.navigateTo({
        url: '../employee/list',
      })
     }
    },
   bindStoreSave: function (e) {
    wx.navigateTo({
      url: '../employee/store_save',
    })
   },
})

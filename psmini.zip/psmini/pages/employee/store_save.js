// index.js
// 获取应用实例
const app = getApp()
const employeeService = require("../../service/employeeService.js");
const common = require("../../assets/js/common.js");

Page({
  data: {},
  onLoad() {
  },
  bindSubmit(e) {
    let params = e.detail.value;
    if(!params.storeName || !params.address || !params.opentime || !params.account || !params.password || !params.name ){
      common.showToast("请填写完整信息！")
    }
    wx.showLoading({
      title: '数据处理中，请稍候...'
    })
    params.userid = wx.getStorageSync('jxsUserId')
    employeeService.saveStore(params).then(res => {
      if (res.data.code == 200) {
        wx.hideLoading()
        common.showToast('创建成功！')
        setTimeout(function () {
          //要延时执行的代码
          wx.navigateTo({
            url: '../employee/store'
          })
        }, 2000) //延迟时间
      } else {
          common.showToast(res.data.message)
      }
    })
  },
})

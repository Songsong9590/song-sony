const app = getApp()
const officialService = require("../../service/officialService.js");
const common = require("../../assets/js/common.js");
const cache = require('../../utils/cache.js');
Page({
  data: {
    picList:[
      "https://sony.zikudata.com/static/index1.png",
      "https://sony.zikudata.com/static/index2.png",
      "https://sony.zikudata.com/static/index3.png",
    ],
    messageList:[],
    images:[]
  },
  onLoad: function() {
    // officialService.getAllNotice({}).then(result => {
    //   if (result.data.code == 200) {
    //     this.setData({
    //       messageList:result.data.data
    //     })
    //   }
    // })
    if (cache.get('jxsUserId')) {
      wx.switchTab({
        url: '/pages/work/work'
      })
    }

  },
  bindUserLogin:function(){
    wx.redirectTo({
      url: '/pages/login/login'
    })
  },
  bindProductSearch:function(){
    wx.redirectTo({
      url: '../product/list'
    })
  },
  bindToInfo:function(data){
    let noticeId = data.currentTarget.dataset.noticeid;
    wx.redirectTo({
      url: '../index/content?noticeId='+noticeId
    })
  },
})
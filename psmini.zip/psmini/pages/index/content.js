const app = getApp()
const officialService = require("../../service/officialService.js");
const common = require("../../assets/js/common.js");
const cache = require('../../utils/cache.js');
Page({
  data: {
    messageInfo:[],
    images:[]
  },
  onLoad: function(option) {
    officialService.getNoticeDetails({"noticeId":option.noticeId}).then(result => {
      console.log(result.data.code)
      if (result.data.code == 200) {
        this.setData({
          messageInfo:result.data.data
        })
      }
    })
  },
})
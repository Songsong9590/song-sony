Page({
  data: {},
  onLoad: function() {
  }
})
// index.js
// 获取应用实例
const app = getApp()
var util = require('../../utils/util.js');
const goodsService = require("../../service/goodsService.js");
const employeeService = require("../../service/employeeService.js");
const common = require("../../assets/js/common.js");
const { communicationdescriptionDelete } = require('../../service/service.js');

Page({
  data: {
    stockData:[],
    stockAllList:[],
    goods:[],
    index:0,
    dealerList:[],
    dealerIndex:0,
    roleid:null,
    params:{
      "userid":"",
      "allotzbkcid":"",
      "spId":"",
      "subJxsUserId":"",
      "startDate":util.startTime(new Date()),
      "endDate":util.formatTime(new Date())
    },
  },
  onLoad() {
    this.getProductList()
    if (wx.getStorageSync('roleid') == '5'){
      this.getDealerList()
    }
    let jxsUserId = wx.getStorageSync('jxsUserId');
    this.setData({
      roleid: wx.getStorageSync('roleid'),
      "params.userid":jxsUserId
    })
    this.getZbSpKcList()
  },
  getZbSpKcList:function(){
    let list = []
    goodsService.getAllotZbKcList(this.data.params).then(res => {
      if (res.data.code == 200) {
        console.log(res.data.data);
        let lists = res.data.data;
        if(lists.length >0){
          for (var i=0;i<lists.length;i++){ 
            var data = lists[i].allotZbKcDesc;
            let name = '';
            for(var s in data) {
              name += data[s].spXx.spmc + ' (' + data[s].kc + ') '
            }
            list.push({
              name: name,
              allotzbkcid:lists[i].id,
              time:lists[i].createDate,
              dealer:lists[i].jxsUser.name
            })
          }
        }
        this.setData({
          stockData:list
        })
      } else {
          common.showToast(res.data.message)
      }
  })
  },
  getDealerList:function(){
    let list = []
    let jxsUserId = wx.getStorageSync('jxsUserId');
    employeeService.getDealerList({"userid":jxsUserId}).then(res => {
      if (res.data.code == 200) {
        list = [{"name":"全部经销商","id":null}]
        let dealer = res.data.data;
        for (var i=0;i<dealer.length;i++){ 
          list.push({
            name:dealer[i].jxsUser.name,
            id:dealer[i].jxsUser.id
          })
          this.setData({
            dealerList:list
          })
        }
      } else {
          common.showToast(res.data.message)
      }
    })
  },
  getProductList:function(){
    let goods = []
    goodsService.getSpAll({}).then(res => {
      if (res.data.code == 200) {
        goods = [{"name":"全部商品","id":null}]
        for (var i=0; i<res.data.data.length; i++){
          goods.push({
            name:res.data.data[i].spmc,
            id: res.data.data[i].id
          })
          this.setData({
            goods:goods
          })
        }
      } else {
          common.showToast(resChildren.data.message)
      }
    })
  },
  bindCreateStock:function(){
    wx.navigateTo({
      url: '../total_stock/save'
    })
  },
  bindPickerChange:function(e){
    this.setData({
      'params.spId': this.data.goods[e.detail.value].id?this.data.goods[e.detail.value].id:"",
      index:e.detail.value
    })
    this.getZbSpKcList()
  },
  bindPickerChangeDealer:function(e){
    this.setData({
      'params.subJxsUserId': this.data.dealerList[e.detail.value].id?this.data.dealerList[e.detail.value].id:"",
      dealerIndex:e.detail.value
    })
    this.getZbSpKcList()
  },
  bindToInfo:function(e){
    if (e.currentTarget.dataset.index >= 0) {
    let index = e.currentTarget.dataset.index;
     wx.navigateTo({
       url: '../total_stock/info?allotzbkcid='+this.data.stockData[index].allotzbkcid,
     })
    }
  },
  changeStartDate:function(e){
    this.setData({
      'params.startDate':e.detail.value
    })
    this.getZbSpKcList()
  },
  changeEndDate:function(e){
    this.setData({
      'params.endDate':e.detail.value
    })
    this.getZbSpKcList()
  },
})

// index.js
// 获取应用实例
const app = getApp()
const goodsService = require("../../service/goodsService.js");
const common = require("../../assets/js/common.js");
Page({
  data: {
    allotzbkcid:null,
    jxsUserId:"",
    stockList:[],
    status:0,
  },
  onLoad(e) {
    let list = [];
    let jxsUserId = wx.getStorageSync('jxsUserId');
    goodsService.getAllotZbKcList({"userid":jxsUserId,"allotzbkcid":e.allotzbkcid}).then(res => {
      if (res.data.code == 200) {
        let lists = res.data.data;
        for (var i=0;i<lists.length;i++){ 
          var data = lists[i].allotZbKcDesc;
          for(var s in data) {
            list.push({
              name:data[s].spXx.spmc,
              sum:data[s].kc,
              time:data[s].createDate
            })
          }
          this.setData({
            stockList:list,
            status:lists[i].shstatus,
            allotzbkcid:e.allotzbkcid,
            jxsUserId:jxsUserId
          })
        }
      } else {
          common.showToast(res.data.message)
      }
  })
  },
  bindBack:function() {
    wx.showLoading({
      title: '数据处理中，请稍候...'
    })
    goodsService.saveFail({"userid":this.data.jxsUserId,"allotzbkcid":this.data.allotzbkcid}).then(res => {
      if (res.data.code == 200) {
        wx.hideLoading()
        common.showToast('审核成功！')
        setTimeout(function () {
          //要延时执行的代码
          wx.navigateTo({
            url: '../stock/stock'
          })
        }, 2000) //延迟时间
      } else {
          common.showToast(res.data.message)
      }
    })
  },
  bindSubmit:function(){
    wx.showLoading({
      title: '数据处理中，请稍候...'
    })
    goodsService.saveSuccess({"userid":this.data.jxsUserId,"allotzbkcid":this.data.allotzbkcid}).then(res => {
      if (res.data.code == 200) {
        wx.hideLoading()
        common.showToast('审核成功！')
        setTimeout(function () {
          //要延时执行的代码
          wx.navigateTo({
            url: '../stock/stock'
          })
        }, 2000) //延迟时间
      } else {
          common.showToast(res.data.message)
      }
    })
  },
})

// index.js
// 获取应用实例
const app = getApp()
const goodsService = require("../../service/goodsService.js");
const common = require("../../assets/js/common.js");
const config = require('../../utils/config.js');

Page({
  data: {
    stockList:[],
    stockAllList:[],
    roleid:""
  },
  onLoad() {
    let list = [];
    let jxsUserId = wx.getStorageSync('jxsUserId');
    let roleid = wx.getStorageSync('roleid')
    this.setData({
      roleid:roleid
    })
    if (roleid == 2) {
      this.getZbSpKcList({"userid":jxsUserId})
    }
    goodsService.getAllStockList({"userid":jxsUserId,"storeid":""}).then(res => {
      if (res.data.code == 200) {
        let stock = res.data.data;
        for (var i=0;i<stock.length;i++){ 
          list.push({
            name:stock[i].spXx.sku,
            num: stock[i].kc,
            storeName:stock[i].store.name,
            dealer:stock[i].jxsUser.name,
            image : config.NODOMAIN + stock[i].spXx.img
          })
        }
        console.log(list)
        this.setData({
          stockList:list
        })
      } else {
          common.showToast(res.data.message)
      }
  })
  },
  getZbSpKcList:function(params){
    let list = []
    goodsService.getZbSpKcList(params).then(res => {
      if (res.data.code == 200) {
        let stock = res.data.data;
        for (var i=0;i<stock.length;i++){ 
          list.push({
            name:stock[i].spXx.sku,
            num: stock[i].kc,
            storeName:"总仓库存",
            dealer:stock[i].jxsUser.name,
            image : config.NODOMAIN + stock[i].spXx.img
          })
        }
        console.log(list)
        this.setData({
          stockAllList:list
        })
      } else {
          common.showToast(res.data.message)
      }
    })
  },
  bindBack:function() {
    wx.navigateTo({
      url: '../total_stock/stock'
    })
  },
  bindSave:function() {
    wx.navigateTo({
      url: '../total_stock/save'
    })
  },
  bindSubmit:function(){
    wx.navigateTo({
      url: '../stock/stock'
    })
  },
})

// index.js
// 获取应用实例
const app = getApp()
const goodsService = require("../../service/goodsService.js");
const employeeService = require("../../service/employeeService.js");
const common = require("../../assets/js/common.js");

Page({
  data: {
    count:10,
    currentTab: 0,
    allCount:100,
    storeName:"闵行区门店",
    statusType:["未审核","成功","拒绝"],
    stockData:[],
  },
  // 事件处理函数
  bindViewTap() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad() {
    let list = [];
    let jxsUserId = wx.getStorageSync('jxsUserId');
    goodsService.getAllotKcList({"userid":jxsUserId,"allotkcid":''}).then(res => {
      if (res.data.code == 200) {
        let lists = res.data.data;
        for (var i=0;i<lists.length;i++){ 
          var data = lists[i].allotKcDesc;
          let name = '';
          for(var s in data) {
            name += data[s].spXx.spmc + ' (' + data[s].kc + ') '
          }
          list.push({
            name: name,
            allotkcid:lists[i].id,
            status:lists[i].shstatus,
            statusName:this.data.statusType[lists[i].shstatus],
            time:lists[i].createDate,
            dealer:lists[i].jxsUser.name,
            storeName:lists[i].store.name?lists[i].store.name:""
          })
          this.setData({
            stockData:list,
            roleid : wx.getStorageSync('roleid')
          })
        }
      } else {
          common.showToast(res.data.message)
      }
  })
  },
  bindCreateStock:function(){
    wx.navigateTo({
      url: '../stock/save'
    })
  },
  bindToInfo:function(e){
    if (e.currentTarget.dataset.index >= 0) {
    let index = e.currentTarget.dataset.index;
     wx.navigateTo({
       url: '../stock/info?allotkcid='+this.data.stockData[index].allotkcid,
     })
    }
  }
})

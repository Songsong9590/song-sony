// index.js
// 获取应用实例
const app = getApp()
const goodsService = require("../../service/goodsService.js");
const common = require("../../assets/js/common.js");
Page({
  data: {
    allotkcid:null,
    jxsUserId:"",
    stockList:[],
    status:0,
  },
  onLoad(e) {
    var pages = getCurrentPages();//页面指针数组
    var backUrl = pages[pages.length - 2].route
    backUrl = backUrl.replace("pages", "..");
    let list = [];
    let jxsUserId = wx.getStorageSync('jxsUserId')
    goodsService.getAllotKcList({"userid":jxsUserId,"allotkcid":e.allotkcid}).then(res => {
      if (res.data.code == 200) {
        let lists = res.data.data;
        for (var i=0;i<lists.length;i++){ 
          var data = lists[i].allotKcDesc;
          for(var s in data) {
            list.push({
              name:data[s].spXx.spmc,
              sum:data[s].kc,
              time:data[s].createDate
            })
          }
          console.log(lists[i].shstatus);
          this.setData({
            stockList:list,
            status:lists[i].shstatus,
            allotkcid:e.allotkcid,
            jxsUserId:jxsUserId,
            backUrl:backUrl,
            activeStatus:e.status?e.status:0
          })
        }
      } else {
          common.showToast(res.data.message)
      }
  })
  },
  bindBack:function() {
    wx.showLoading({
      title: '数据处理中，请稍候...'
    })
    let that = this
    goodsService.saveFail({"userid":this.data.jxsUserId,"allotkcid":this.data.allotkcid}).then(res => {
      if (res.data.code == 200) {
        wx.hideLoading()
        common.showToast('审核成功！')
        setTimeout(function () {
          //要延时执行的代码
          if(that.data.activeStatus == "1") {
            wx.switchTab({
              url:that.data.backUrl
            })
          } else {
            wx.navigateTo({
              url: that.data.backUrl
            })
          }
        }, 2000) //延迟时间
      } else {
          common.showToast(res.data.message)
      }
    })
  },
  bindSubmit:function(){
    wx.showLoading({
      title: '数据处理中，请稍候...'
    })
    let that = this
    goodsService.saveSuccess({"userid":this.data.jxsUserId,"allotkcid":this.data.allotkcid}).then(res => {
      if (res.data.code == 200) {
        wx.hideLoading()
        common.showToast('审核成功！')
        setTimeout(function () {
          //要延时执行的代码
          if(that.data.activeStatus == "1") {
            wx.switchTab({
              url:that.data.backUrl
            })
          } else {
            wx.navigateTo({
              url: that.data.backUrl
            })
          }
        }, 2000) //延迟时间
      } else {
          common.showToast(res.data.message)
      }
    })
  },
})

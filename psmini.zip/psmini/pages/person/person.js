// index.js
// 获取应用实例
const app = getApp()
const employeeService = require("../../service/employeeService.js");

Page({
  data: {
    userInfo: {},
    roleType:["未知","总部超管","经销商管理员","门店店长","店员","总代理"]
  },
  onLoad() {
    let jxsUserId = wx.getStorageSync('jxsUserId');
    employeeService.getUserInfo({"userid":jxsUserId}).then(res => {
      if (res.data.code == 200) {
        console.log(res.data);
        this.data.userInfo = {
          "role":this.data.roleType[res.data.data.roleid],
          "name":res.data.data.name,
          "account":res.data.data.account,
          "mobile":res.data.data.phone,
          "password":res.data.data.password,
        }
        this.setData({
          userInfo:this.data.userInfo
        })
      } else {
          common.showToast(res.data.message)
      }
    })
  },
  bindGetOut:function(){
    wx.clearStorageSync();
    wx.reLaunch({
      url: '/pages/index/index',
    })
  },
  bindUpdatePassword:function(){
    wx.navigateTo({
      url: '/pages/update_password/update_password'
    })
  },
})

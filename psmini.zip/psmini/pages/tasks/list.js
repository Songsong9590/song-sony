var util = require('../../utils/util.js');
const tasksService = require("../../service/tasksService.js");
const common = require("../../assets/js/common.js");
Page({
  data: {
    params:{
      "userId":null,
    },
    roleid:"",
    taskData:[],
    statusType:["正常","禁用"]
  },
  onShow(){
    this.data.params.userId = wx.getStorageSync('jxsUserId')
    let roleid = wx.getStorageSync('roleid')
    this.setData({
      roleid:roleid
    })
    switch (roleid) {
      case '5':
        // this.data.params.userId = "1551408049849356288";
        this.getTotalSaleTask(this.data.params)
        break;
      case '2':
        // this.data.params.userId = "1468453487442038784";
        this.getTheSubJxsTask(this.data.params)
        break;
      default:
        let storeId = wx.getStorageSync('storeId');  
        this.getSaleTasksByStore({"storeId":storeId})
        break;
    }
  },
  getTotalSaleTask:function(params) {
    tasksService.getTotalSaleTask(params).then(res => {
      if (res.data.code == 200) {
        this.setData({
          taskData: res.data.data
        })
      } else {
        common.showToast(res.data.message)
      }
    })
  },
  getTheSubJxsTask:function(params) {
    tasksService.getTheSubJxsTask(params).then(res => {
      if (res.data.code == 200) {
        this.setData({
          taskData: res.data.data
        })
      } else {
        common.showToast(res.data.message)
      }
    })
  },
  getSaleTasksByStore:function(params) {
    tasksService.getSaleTasksByStore(params).then(res => {
      if (res.data.code == 200) {
        this.setData({
          taskData: res.data.data
        })
      } else {
        common.showToast(res.data.message)
      }
    })
  },
  bindSaveTasks:function() {
    wx.navigateTo({
      url: '/pages/tasks/save'
    })
  },
  bindMyTasks:function() {
    wx.navigateTo({
      url: '/pages/tasks/my'
    })
  }
})
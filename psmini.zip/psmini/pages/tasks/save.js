// index.js
// 获取应用实例
const app = getApp()
const tasksService = require("../../service/tasksService.js");
const employeeService = require("../../service/employeeService.js");
const common = require("../../assets/js/common.js");

Page({
  data: {
    isShow:true,
    tasksData:{userId:"",storeId:"",finlaSaleNums:"",month:""},
    storeList:[],
    monthList:[1,2,3,4,5,6,7,8,9,10,11,12],
    monthIndex:0,
    index:0,
    group:0
  },
  onLoad() {
    let list = [];
    var that = this
    let jxsUserId = wx.getStorageSync('jxsUserId');
    employeeService.getStoreList({"jxsUserId":jxsUserId}).then(res => {
      if (res.data.code == 200) {
        let stores = res.data.data;
        for (var i=0;i<stores.length;i++){ 
          list.push({
            name:stores[i].store.name,
            id:stores[i].store.id
          })
          this.data.tasksData.userId = wx.getStorageSync('jxsUserId');
          if (this.data.index == i){
            this.data.tasksData.storeId = stores[i].store.id;
          }
          this.setData({
            tasksData:this.data.tasksData,
            storeList:list
          })
        }
      } else {
          common.showToast(res.data.message)
      }
    })
  },
  bindPickerChange: function(e) {
    this.setData({
      'tasksData.storeId': this.data.storeList[e.detail.value].id,
      index:e.detail.value
    })
  },
  bindFinlaSaleNumsInput:function(e){
    this.data.tasksData.finlaSaleNums = e.detail.value; 
    this.setData({
      tasksData:this.data.tasksData,
    })
  },
  bindMonthInput:function(e){
    this.data.tasksData.month = e.detail.value; 
    this.setData({
      tasksData:this.data.tasksData,
    })
  },
  bindSubmit:function(){
    let tasks = this.data.tasksData
    if (!tasks) {
      common.showToast("参数有误，请检查后再次提交！")
    }
    wx.showLoading({
      title: '数据处理中，请稍候...'
    })
    tasksService.depolyTaskToStores(tasks).then(res => {
      if (res.data.code == 200) {
        wx.hideLoading()
        common.showToast('创建任务成功！')
        setTimeout(function () {
          //要延时执行的代码
          wx.navigateTo({
            url: '../tasks/list'
          })
        }, 2000) //延迟时间
      } else {
          common.showToast(res.data.message)
      }
    })
  },
  bindBack:function(){
    wx.navigateTo({
      url: '../stock/stock'
    })
  },
  bindPickerChangeMonth:function(e){
    console.log(e)
    this.setData({
      'tasksData.month': this.data.monthList[e.detail.value],
      monthIndex:e.detail.value
    })
  }
})

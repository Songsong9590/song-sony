var util = require('../../utils/util.js');
const tasksService = require("../../service/tasksService.js");
const common = require("../../assets/js/common.js");
Page({
  data: {
    params:{
      "userId":null,
    },
    roleid:"",
    taskData:[],
    statusType:["正常","禁用"]
  },
  onShow(){
    this.data.params.userId = wx.getStorageSync('jxsUserId')
    let roleid = wx.getStorageSync('roleid')
    this.setData({
      roleid:roleid
    })
    this.getJxsUsersTasks(this.data.params)
  },
  getJxsUsersTasks:function(params) {
    tasksService.getJxsUsersTasks(params).then(res => {
      if (res.data.code == 200) {
        this.setData({
          taskData: res.data.data
        })
      } else {
        common.showToast(res.data.message)
      }
    })
  },
})
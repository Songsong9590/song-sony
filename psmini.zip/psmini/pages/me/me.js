// index.js
// 获取应用实例
const app = getApp()
const loginService = require("../../service/loginService.js");
const common = require("../../assets/js/common.js");
Page({
  data: {
    userInfo: {},
    hasUserInfo: false,
    roleid:null,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
  },
  onLoad() {
    let roleid = wx.getStorageSync('roleid');
    this.setData({
      roleid: roleid
    })
  },
  onShow() {
    wx.login({
      success: res => {
          // 发送 res.code 到后台换取 openId, sessionKey, unionId
          if (res.code) {
            loginService.authLogin({code:res.code}).then(result => {
              if (result.data.code == 200) {
                wx.setStorageSync('token', result.data.data.token);
                this.getUsers()
              } else {
                  common.showToast(result.data.message)
              }
          })
          } else {
              console.log('获取用户登录态失败！' + res.errMsg)
          }
      }
    })
  },
  getUsers() {
    loginService.getUserInfo({}).then(result => {
      if (result.data.code == 200) {
        if (!("wxtx" in result.data.data)) {
          this.setData({
            hasUserInfo: false
          })
        } else {
          let userInfos = {"nickName":result.data.data.wxnc,"avatarUrl":result.data.data.wxtx,"id":result.data.data.id}
          this.setData({
            userInfo:userInfos,
            hasUserInfo: true
          })
        }
      } else {
          common.showToast(result.data.message)
      }
    })
  },
  getUserInfo() {
    wx.getUserProfile({ desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写 
    success: (res) => { 
      loginService.saveUserInfo({nickname:res.userInfo.nickName,avatar:res.userInfo.avatarUrl}).then(result => {
        if (result.data.code == 200) {
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        } else {
            common.showToast(result.data.message)
        }
      })
    }, 
    fail: res => { 
      console.log("获取用户信息失败", res) 
    } 
  })
  },
  bindToPerson:function(){
    wx.navigateTo({
      url: '/pages/person/person'
    })
  },
  bindToUpdatePassword:function(){
    wx.navigateTo({
      url: '/pages/update_password/update_password'
    })
  },
  bindToEmployee:function(){
    wx.navigateTo({
      url: '/pages/employee/store'
    })
  },
  bindToQuestion:function(){
    wx.navigateTo({
      url: '/pages/question/index'
    })
  },
})

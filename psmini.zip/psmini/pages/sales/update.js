// index.js
// 获取应用实例
const app = getApp()
const goodsService = require("../../service/goodsService.js");
const salesService = require("../../service/salesService.js");
const common = require("../../assets/js/common.js");

Page({
  data: {
    salesData:[{code:"",name:"",list_code:[{"code":""}],sum:0,price:"0.00",isShow:true}],
    storeList:[],
    index:0
  },
  onLoad(options) {
    let list = [];
    let list_code = []
    if (options.orderId) {
      salesService.getOrderList({"id":options.orderId}).then(res => {
        if (res.data.code == 200) {
          let lists = res.data.data[0].order_desc_list;
          console.log(lists);
          for(var i in lists){
            list.push({
              code:lists[i].spXx.pm,
              name: lists[i].spXx.spmc,
              xh: lists[i].spXx.xh,
              price: lists[i].price,
              sum: lists[i].inputNum,
              id: lists[i].spXx.id,
              list_code:[]
            })
            if (lists[i].seriesId){
              let listCode = lists[i].seriesId.split("#");
              list[i].list_code = listCode.map(item => ({code:item}));
            } else {
              list[i].isShow = true
            }
            this.setData({
              salesData:list,
              orderId:options.orderId
            })
          }
        } else {
            common.showToast(res.data.message)
        }
      })
    }
  },
  bindSubmit:function(){
    wx.showLoading({
      title: '数据处理中，请稍候...'
    })
    let salesData = this.data.salesData;
    let goodsIds = '',
    prices = '',
    codes = '',
    nums = '';
    for(var i in salesData) {
      if (salesData[i].id && salesData[i].price && salesData[i].list_code) {
        let listCode = salesData[i].list_code,
        code = '';
        for(var s in listCode) {
          if (listCode[s].code) {
            if (s > 0 && listCode[s].code){
              code += '#';
            }
            code += listCode[s].code;
          }
        }
        if (i > 0){
          goodsIds += salesData[i].id?',':'';
          prices += salesData[i].price?',':'';
          codes += code?',':'';
          nums += salesData[i].sum?',':'';
        }
        goodsIds += salesData[i].id?salesData[i].id:'';
        prices += salesData[i].price?salesData[i].price:'';
        codes += code?code:'';
        nums += salesData[i].sum?salesData[i].sum:'';
      } else {
        common.showToast("请补充完整信息")
      }
    }
    let data = {
      'user_id':wx.getStorageSync('jxsUserId'),
      'commd_str_list':goodsIds,
      'price':prices,
      'series_id':codes,
      'input_num':nums,
      'order_id':this.data.orderId
    }
    salesService.updateSalesOrder(data).then(res => {
      if (res.data.code == 200) {
        wx.hideLoading()
        common.showToast('修改销售订单成功！')
        setTimeout(function () {
          //要延时执行的代码
          wx.navigateTo({
            url: '../sales/list'
          })
        }, 2000) //延迟时间
      } else {
          common.showToast(res.data.message)
      }
    })
  },
  bindLess:function(event){
    var index = event.currentTarget.dataset.index;
    this.data.salesData[index].sum--
    this.setData({
      salesData:this.data.salesData
    })
  },
  bindPlus:function(event){
    var index = event.currentTarget.dataset.index;
    this.data.salesData[index].sum++;
    this.setData({
      salesData:this.data.salesData
    })
  },
  createCode:function(event){
    var index = event.currentTarget.dataset.index;
    this.data.salesData[index].list_code.push({code:""})
    this.setData({
      salesData:this.data.salesData
    })
  },
  bindScanCode:function(event){
    var index = event.currentTarget.dataset.index;
    wx.scanCode({
      success: (res) => {
        this.data.salesData[index].code = res.result;
        this.setData({
          salesData:this.data.salesData,
        })
      },
      fail: (res) => {
      }
    })
  },
  bindPickerChange: function(e) {
    this.setData({
      index:e.detail.value
    })
  },
  bindCodeInput:function(e){
    this.data.salesData[e.currentTarget.dataset.index].code = e.detail.value; 
    this.setData({
      salesData:this.data.salesData,
    })
  },
  bindCodeBlur:function(e){
    if(e.detail.value){
      goodsService.getSpByPM({"PM":e.detail.value}).then(res => {
        if (res.data.code == 200) {
          this.data.salesData[e.currentTarget.dataset.index].name = res.data.data.spmc;
          this.data.salesData[e.currentTarget.dataset.index].id = res.data.data.id;
          this.setData({
            salesData:this.data.salesData
          })
        } else {
            common.showToast(res.data.message)
        }
      })
    }
  },
  bindXLCodeBlur:function(e){
    this.data.salesData[e.currentTarget.dataset.index].isShow = e.detail.value == ''? true:false;
    this.data.salesData[e.currentTarget.dataset.index].list_code[e.currentTarget.dataset.codeindex].code = e.detail.value
    this.setData({
      salesData:this.data.salesData
    })
  },
  bindPriceBlur:function(e){
    this.data.salesData[e.currentTarget.dataset.index].price = e.detail.value
    this.setData({
      salesData:this.data.salesData
    })
  }
})

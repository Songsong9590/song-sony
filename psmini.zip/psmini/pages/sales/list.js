var util = require('../../utils/util.js');
const salesService = require("../../service/salesService.js");
const employeeService = require("../../service/employeeService.js");
const common = require("../../assets/js/common.js");
Page({
  data: {
    selectLeftShow: false,//控制下拉列表的显示隐藏，false隐藏、true显示
    selectLeftData: [],//下拉列表的数据
    selectRightShow: false,//控制下拉列表的显示隐藏，false隐藏、true显示
    selectRightData: [],//下拉列表的数据
    leftIndex: 0,//选择的下拉列表下标
    rightIndex: 0,//选择的下拉列表下标
    status : 1,
    statusType:{'pending':"待审核","pass":"已审核","fail":"审核失败","pending_again":"重审中"},
    params:{
      "id":"",
      "store_id":"",
      "user_id":"",
      "employee_id":"",
      "page":1,
      "begin_time":util.startTime(new Date()),
      "end_time":util.formatTime(new Date())
    },
    count:0,
    salesData:[],
    roleid:""
  },
  onLoad(options){
    this.setData({
      status: options.status ? options.status :1,
      roleid : wx.getStorageSync('roleid')
    });
  },
  onShow(){
    this.data.params.user_id = wx.getStorageSync('jxsUserId')
    this.getStoreList({"jxsUserId":this.data.params.user_id})
    this.getDataList(this.data.params)
  },
  // 点击下拉显示框
  selectLeftTap() {
    this.setData({
      selectLeftShow: !this.data.selectLeftShow
    });
  },
  // 点击下拉列表
  optionLeftTap(e) {
    let Index = e.currentTarget.dataset.index;//获取点击的下拉列表的下标
    this.data.params.store_id = this.data.selectLeftData[Index].id
    this.getDataList(this.data.params)
    this.getEmployeeList(this.data.params.store_id?{"storeid":this.data.params.store_id}:{"userid":this.data.params.user_id,"storeid":this.data.params.store_id});
    this.setData({
      leftIndex: Index,
      selectLeftShow: !this.data.selectLeftShow
    });
  },
    // 点击下拉显示框
    selectRightTap() {
      this.setData({
        selectRightShow: !this.data.selectRightShow
      });
    },
    // 点击下拉列表
    optionRightTap(e) {
      let Index = e.currentTarget.dataset.index;//获取点击的下拉列表的下标
      this.data.params.employee_id = this.data.selectRightData[Index].id
      this.getDataList(this.data.params)
      this.setData({
        rightIndex: Index,
        selectRightShow: !this.data.selectRightShow
      });
    },
    // 点击下拉显示框
    bindSearch() {
      this.setData({
        status: 1,
      });
    },
    // 点击下拉列表
    bindSales(e) {
      this.setData({
        status: 2,
      });
    },
    bindToSalesInfo:function(e){
      if(e.currentTarget.dataset.status == 'pending_again') {
        if (this.data.roleid != 2) return false;
      }
      wx.navigateTo({
        url: '../sales/sales_info?orderId='+e.currentTarget.dataset.orderid,
      })
    },
    changeStartDate:function(e){
      this.setData({
        'params.begin_time':e.detail.value
      })
      this.getDataList(this.data.params)
    },
    changeEndDate:function(e){
      this.setData({
        'params.end_time':e.detail.value
      })
      this.getDataList(this.data.params)
    },
    getDataList:function(params,list = []) {
      salesService.getOrderList(params).then(res => {
        if (res.data.code == 200) {
          let lists = res.data.data.list;
          if (lists.length == 0) {
            wx.showToast({
              title:'没有更多数据了',
              icon:'none'
            })
            that.setData({
                isloading:true
            })
          }
          for(var i in lists) {
            var data = lists[i].spDesc;
            let name = '';
            for(var s in data) {
              name += data[s].spXx?data[s].spXx.spmc + ' (' + data[s].inputNum + ') ':""
            }
            list.push({
              name: name,
              id:lists[i].id,
              status:lists[i].shstatus,
              statusName:this.data.statusType[lists[i].shstatus],
              date:lists[i].insertTime,
              dealer:lists[i].jxsUser.name?lists[i].jxsUser.name:"",
              storeName:lists[i].store.name?lists[i].store.name:"",
            })
          }
          this.setData({
            salesData:list,
            params:params,
            count:res.data.data.count
          })
          wx.hideLoading();

        } else {
            common.showToast(res.data.message)
        }
      })
    },
    getStoreList:function(params){
      let list = []
      let that = this;
      employeeService.getStoreList(params).then(res => {
        if (res.data.code == 200) {
          let stores = res.data.data;
          that.data.params.user_id = params.jxsUserId
          //that.data.params.store_id = stores[0].store.id
          //that.getDataList(that.data.params)
          that.getEmployeeList({"storeid":stores[0].store.id});
          list.push({
            name:"全部门店",
            id:""
          })
          for (var i=0;i<stores.length;i++){ 
            list.push({
              name:stores[i].store.name,
              id:stores[i].store.id
            })
            this.setData({
              selectLeftData:list
            })
          }
        } else {
            common.showToast(res.data.message)
        }
    })
  },
  getEmployeeList:function(params= {}){
    let list = []; 
    employeeService.getStoreUser(params).then(res => {
      if (res.data.code == 200) {
        let employees = res.data.data;
        list.push({
          name:"全部店员",
          id:""
        })
        if (employees.length > 0) {
          for (var i=0;i<employees.length;i++){ 
            list.push({
              name:employees[i].jxsUser.name,
              id:employees[i].jxsUser.id
            })
          }
        }
        this.setData({
          selectRightData:list
        })
      } else {
          common.showToast(res.data.message)
      }
    })
  },
  searchOrder:function(e){
    this.data.params.id = e.detail.value;
    this.getDataList(this.data.params)
  },
 /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this;
    var pageSize = that.data.count/10;
    if(pageSize <= that.data.params.page){
      wx.showToast({
        title: '没有更多数据了',
        icon:'none'
      })
      return false;
    }
    wx.showLoading({
      title: '加载中',//加载转圈显示
    });
    that.setData({
      "params.page":that.data.params.page+1
    })
    var params = that.data.params;
    that.getDataList(params,that.data.salesData)
  },
})
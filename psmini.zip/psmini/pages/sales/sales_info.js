// index.js
// 获取应用实例
const app = getApp();
const salesService = require("../../service/salesService.js");
const common = require("../../assets/js/common.js");

Page({
  data: {
    salesData:[],
    roleid:""
  },
  onLoad(options) {
    console.log(options)
    var pages = getCurrentPages();//页面指针数组
    var backUrl = pages[pages.length - 2].route
    backUrl = backUrl.replace("pages", "..");
    let list = [];
    this.setData({
      roleid:wx.getStorageSync('roleid'),
      backUrl:backUrl,
      activeStatus:options.status?options.status:0
    })
    if (options.orderId) {
      salesService.getOrderList({"id":options.orderId}).then(res => {
        if (res.data.code == 200) {
          let lists = res.data.data.list;
          for(var i in lists) {
            var data = lists[i].spDesc;
            var status = lists[i].shstatus
            for(var s in data) 
              list.push({
                name: data[s].spXx.spmc,
                xh: data[s].spXx.xh,
                price: data[s].price,
                sum: data[s].inputNum,
                date: lists[i].insertTime,
                list_code: !data[s].seriesId || data[s].seriesId == ' '?[]:data[s].seriesId.split("#"),
                storeName:lists[i].store.name
              })
              this.setData({
                salesData:list,
                orderId:options.orderId,
                status:status
              })
            }
        } else {
            common.showToast(res.data.message)
        }
      })
    }
  },
  bindCreate:function() {
    this.data.salesData.push({
      code:"",
      name:"",
      list_code:"",
      sum:"0",
      price:"0.00",
    })
    this.setData({
      salesData:this.data.salesData
    })
  },
  bindBack:function() {
    let params = {"user_id":wx.getStorageSync('jxsUserId'),"id":this.data.orderId,"remark":"","status":"fail"}
    this.updateOrderStatus(params)
  },
  bindSubmit:function(){
    let params = {"user_id":wx.getStorageSync('jxsUserId'),"id":this.data.orderId,"remark":"","status":"pass"}
    this.updateOrderStatus(params)
  },
  updateOrderStatus:function(params = {}){
    wx.showLoading({
      title: '数据处理中，请稍候...'
    })
    let that = this
    salesService.changeStatus(params).then(res => {
      if (res.data.code == 200) {
        wx.hideLoading()
        common.showToast('审核成功！')
        setTimeout(function () {
          //要延时执行的代码
          if(that.data.activeStatus == "1") {
            wx.switchTab({
              url:that.data.backUrl
            })
          } else {
            wx.navigateTo({
              url: that.data.backUrl
            })
          }
        }, 2000) //延迟时间
      } else {
          common.showToast(res.data.message)
      }
    })
  },
  bindUpdate:function(e){
    wx.navigateTo({
      url: '../sales/update?orderId='+this.data.orderId
    })
  }
})

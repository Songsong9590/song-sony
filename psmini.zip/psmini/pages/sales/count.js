var util = require('../../utils/util.js');
const salesService = require("../../service/salesService.js");
const employeeService = require("../../service/employeeService.js");
const common = require("../../assets/js/common.js");
Page({
  data: {
    data:[],
    roleid:"",
    dealerList:[],
    index:0,
    params:{
      "userid":"",
      "commodityId":"",
      "startDate":util.startTime(new Date()),
      "endDate":util.formatTime(new Date()),
      "subJxsUserId":''
    },
  },
  onLoad(options){
    this.getDataList()
    this.getDealerList()
  },
  getDataList:function() {
    wx.showLoading({
      title:'加载中'
    })
    let list = []
    this.data.params.userid = wx.getStorageSync('jxsUserId')
    salesService.getSalesCount(this.data.params).then(res => {
      if (res.data.code == 200) {
        list = res.data.data;
        this.setData({
          data:list,
        })
        wx.hideLoading()
      } else {
          common.showToast(res.data.message)
      }
    })
  },
  getDealerList:function(){
    let list = [{"name":"全部经销商","id":""}];
    let jxsUserId = wx.getStorageSync('jxsUserId');
    employeeService.getDealerList({"userid":jxsUserId}).then(res => {
      if (res.data.code == 200) {
        let dealer = res.data.data;
        console.log(dealer)
        for (var i=0;i<dealer.length;i++){ 
          list.push({
            name:dealer[i].jxsUser.name,
            id:dealer[i].jxsUser.id
          })
          if (this.data.index == i){
            this.data.params.userid = dealer[i].jxsUser.id;
          }
          this.setData({
            dealerList:list,
            params:this.data.params
          })

        }
      } else {
          common.showToast(res.data.message)
      }
    })
  },
  changeStartDate:function(e){
    this.setData({
      'params.startDate':e.detail.value
    })
    this.getDataList(this.data.params)
  },
  changeEndDate:function(e){
    this.setData({
      'params.endDate':e.detail.value
    })
    this.getDataList(this.data.params)
  },
  bindPickerChange: function(e) {
    this.setData({
      'params.subJxsUserId': this.data.dealerList[e.detail.value].id,
      index:e.detail.value
    })
    this.getDataList()
  },
}) 
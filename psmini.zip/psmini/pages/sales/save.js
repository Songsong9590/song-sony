// index.js
// 获取应用实例
const app = getApp()
const goodsService = require("../../service/goodsService.js");
const employeeService = require("../../service/employeeService.js");
const salesService = require("../../service/salesService.js");
const common = require("../../assets/js/common.js");
const config = require('../../utils/config.js');

Page({
  data: {
    isShow:true,
    salesData:[{code:"",name:"",list_code:[{"code":""}],sum:0,price:"0.00",isShow:true,isNeedxlh:"1"}],
    storeList:[],
    index:0,
    group:0
  },
  onLoad() {
    let list = [];
    var that = this
    that.ctx = wx.createCameraContext()
    let jxsUserId = wx.getStorageSync('jxsUserId');
    employeeService.getStoreList({"jxsUserId":jxsUserId}).then(res => {
      if (res.data.code == 200) {
        let stores = res.data.data;
        for (var i=0;i<stores.length;i++){ 
          list.push({
            name:stores[i].store.name,
            id:stores[i].store.id,
          })
          this.setData({
            storeList:list
          })
        }
      } else {
          common.showToast(res.data.message)
      }
    })
    wx.getSystemInfo({
      success: function (res) {
        var width = res.windowWidth
        var height = res.windowHeight
        var gap = 150
        that.setData({
          width: width+50,
          height: height+50,
          gap: gap
        })
      }
    })
  },
  bindCreate:function() {
    this.data.salesData.push({
      code:"",
      name:"",
      list_code:[{"code":""}],
      sum:0,
      price:"0.00",
      isShow:true,
      isNeedxlh:"1"
    })
    this.setData({
      salesData:this.data.salesData
    })
  },
  bindDelete:function() {
    var index = this.data.salesData.length-1;
    if (index > 0) {
      this.data.salesData.splice(index,1);
      this.setData({
        salesData:this.data.salesData
      })
    }
  },
  bindSubmit:function(){
    let salesData = this.data.salesData;
    let goodsIds = '',
    prices = '',
    codes = '',
    nums = '';
    for(var i in salesData) {
      if (salesData[i].id && salesData[i].price && salesData[i].list_code) {
        let listCode = salesData[i].list_code,
        code = '';
        for(var s in listCode) {
          if (listCode[s].code) {
            if (s > 0 && listCode[s].code){
              code += '#';
            }
            code += listCode[s].code;
          }
        }
        if (i > 0){
          goodsIds += salesData[i].id?',':'';
          prices += salesData[i].price?',':'';
          codes += code?',':'';
          nums += salesData[i].sum?',':'';
        }
        goodsIds += salesData[i].id?salesData[i].id:'';
        prices += salesData[i].price?salesData[i].price:'';
        codes += code?code:'';
        nums += salesData[i].sum?salesData[i].sum:'';
      } else {
        common.showToast("请补充完整信息");
        return false;
      }
    }
    wx.showLoading({
      title: '数据处理中，请稍候...'
    })
    let data = {
      'user_id':wx.getStorageSync('jxsUserId'),
      'store_id':this.data.storeList[this.data.index].id,
      'commd_str_list':goodsIds,
      'price':prices,
      'series_id':codes,
      'input_num':nums
    }
  
    salesService.saveSalesOrder(data).then(res => {
      if (res.data.code == 200) {
        wx.hideLoading()
        common.showToast('创建销售订单成功！')
        setTimeout(function () {
          //要延时执行的代码
          wx.navigateTo({
            url: '../sales/list'
          })
        }, 2000) //延迟时间
      } else {
          common.showToast(res.data.message)
      }
    })
  },
  bindSumBlur:function(e){
    this.data.salesData[e.currentTarget.dataset.index].sum = e.detail.value; 
    if(e.detail.value == "0") {
      common.showToast("销售订单录入数量不能为0");
      return false;
    }
    this.setData({
      salesData:this.data.salesData,
    })
  },
  bindLess:function(event){
    var index = event.currentTarget.dataset.index;
    if(this.data.salesData[index].sum == '0') {
      common.showToast("销售订单录入数量不能为负数");
      return false;
    }
    this.data.salesData[index].sum--;
    this.setData({
      salesData:this.data.salesData
    })
  },
  bindPlus:function(event){
    var index = event.currentTarget.dataset.index;
    this.data.salesData[index].sum++;
    this.setData({
      salesData:this.data.salesData
    })
  },
  createCode:function(event){
    var index = event.currentTarget.dataset.index;
    this.data.salesData[index].list_code.push({code:""})
    this.setData({
      salesData:this.data.salesData
    })
  },
  bindScanCode:function(event){
    var index = event.currentTarget.dataset.index;
    console.log(index)
    wx.scanCode({
      scanType:[],
      success: (res) => {
        this.data.salesData[index].code = res.result;
        this.data.salesData[index].key = 0;
        this.setData({
          salesData:this.data.salesData,
        })
      },
      fail: (res) => {
      }
    })
  },
  // bindScanCode:function(event){
  //   let index = event.currentTarget.dataset.index;
  //   this.setData({
  //     isShow:false,
  //     group:index
  //   })
  // },
  // 点击扫描名片
  takePhoto: function (event) {
    var that = this
    that.ctx.takePhoto({
      quality: 'high',
      success: (res) => {
        console.log("res",res)
        wx.setStorage({
          key: 'originalImagePath',
          data: res.tempImagePath,
        })
        that.setData({
          photo: res.tempImagePath,
          isShow:true
        })
        setTimeout(function () {
          that.lookQrcode(res.tempImagePath,event.currentTarget.dataset.index)
        }, 500);
      }
    })
  },
  // 开始识别名片信息
  lookQrcode(url,index) {
    wx.showLoading({
      title: '识别中...',
      mask: true
    })
    var that = this;
    const token = wx.getStorageSync('token') || '';
    wx.uploadFile({
      url: config.DOMAIN + '/shipApi/business_card/scanBarcode', //将图片传到服务器的请求路径
      filePath: url, //图片在手机里的存储路径
      name: 'file',
      header: {
        "Content-Type": "multipart/form-data",
        "X-Auth-Token": token
      },
      formData: {"user":"test"},
      success(uploadResult) {
        let result = JSON.parse(uploadResult.data);
        wx.hideLoading()
        if(result.code == 200){
          goodsService.getSpByPM({"PM":result.data[0]}).then(res => {
            if (res.data.code == 200) {
              that.data.salesData[index].code = result.data[0];
              that.data.salesData[index].name = res.data.data.spmc;
              that.data.salesData[index].id = res.data.data.id;
              that.data.salesData[index].isNeedxlh = res.data.data.isneedxlh;
              that.data.salesData[index].isShow = res.data.data.isneedxlh == 1 ? false :true;
              that.setData({
                salesData:that.data.salesData
              })
            } else {
                common.showToast(res.data.message)
            }
          })
        } else {
          common.showToast(result.message)
        }
      }
    })
  },
  bindScanListCode:function(event){
    var index = event.currentTarget.dataset.index;
    var codeindex = event.currentTarget.dataset.codeindex;
    wx.scanCode({
      success: (res) => {
        this.data.salesData[index].list_code[codeindex].code = res.result;
        this.setData({
          salesData:this.data.salesData,
        })
      },
      fail: (res) => {
      }
    })
  },
  bindPickerChange: function(e) {
    this.setData({
      index:e.detail.value
    })
  },
  bindCodeInput:function(e){
    this.data.salesData[e.currentTarget.dataset.index].code = e.detail.value; 
    this.setData({
      salesData:this.data.salesData,
    })
  },
  bindCodeBlur:function(e){
    if(e.detail.value){
      goodsService.getSpByPM({"PM":e.detail.value}).then(res => {
        if (res.data.code == 200) {
          this.data.salesData[e.currentTarget.dataset.index].name = res.data.data.spmc;
          this.data.salesData[e.currentTarget.dataset.index].id = res.data.data.id;
          this.data.salesData[e.currentTarget.dataset.index].isNeedxlh = res.data.data.isneedxlh;
          this.data.salesData[e.currentTarget.dataset.index].isShow = res.data.data.isneedxlh == 1 ? false :true;
          console.log(this.data.salesData[e.currentTarget.dataset.index]);
          this.setData({
            salesData:this.data.salesData
          })
        } else {
            common.showToast(res.data.message)
        }
      })
    }
  },
  bindXLCodeBlur:function(e){
    this.data.salesData[e.currentTarget.dataset.index].isShow = e.detail.value == ''? true:false;
    this.data.salesData[e.currentTarget.dataset.index].list_code[e.currentTarget.dataset.codeindex].code = e.detail.value
    this.setData({
      salesData:this.data.salesData
    })
  },
  bindPriceBlur:function(e){
    console.log(e)
    this.data.salesData[e.currentTarget.dataset.index].price = e.detail.value
    this.setData({
      salesData:this.data.salesData
    })
  },
  deleteCode:function(e){
    var index = e.currentTarget.dataset.index;
    console.log(index)
    this.data.salesData[index].list_code.splice(1,1)
    this.setData({
      salesData:this.data.salesData
    })
  }
})

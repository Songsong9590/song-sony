// index.js
// 获取应用实例
const app = getApp()
const loginService = require("../../service/loginService.js");
const common = require("../../assets/js/common.js");
const config = require('../../utils/config.js');
Page({
  data: {
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    count:{},
    roleId:'',
    display:"none",
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    menus:[],
    type:{"allotKcs":"库存","orders":"销售","users":"员工"},
    status:{"allotKcs":"1","orders":"0","users":"2"},
    tag:"",
    roleType:["未知","总部超管","经销商管理员","门店店长","店员","总代理"]
  },
  onLoad() {
    let menus = [];
    let roleid = wx.getStorageSync('roleid');
    let roleName = wx.getStorageSync('roleName');
    if (roleid == 5){
      menus = [{"name":"销售概览","url":"../sales/count"}];
    }
    menus.push({"name":"销售记录","url":"../sales/list?status=1"},{"name":"产品信息","url":"../product/list"},{"name":"任务","url":"../tasks/list"})
    this.setData({
      menus:menus,
      roleid:roleid,
      tag:roleName + this.data.roleType[roleid]
    })
  },
  onShow() {
    wx.login({
      success: res => {
          // 发送 res.code 到后台换取 openId, sessionKey, unionId
          if (res.code) {
            loginService.authLogin({code:res.code}).then(result => {
              if (result.data.code == 200) {
                wx.setStorageSync('token', result.data.data.token);
                this.getUsers()
                if (!wx.getStorageSync('saleCount') || !wx.getStorageSync('cacheTime') || new Date().getTime() > wx.getStorageSync('cacheTime')){
                  this.getCount() 
                } else {
                  this.data.count = {
                    "saleCount": wx.getStorageSync('saleCount'),//累计销量
                    "todaySaleCount": wx.getStorageSync('tdSaleCount'),//今日销量
                    "yesterdaySaleCount": wx.getStorageSync('ydSaleCount'),//昨日销售
                  }
                  this.setData({
                    count:this.data.count
                  })
                }
                this.getDaiBan({"userid":wx.getStorageSync('jxsUserId')});
              } else {
                  // common.showToast(result.data.message)
              }
          })
          } else {
              console.log('获取用户登录态失败！' + res.errMsg)
          }
      }
    })
  },
  getCount:function(){
    let jxsUserId = wx.getStorageSync('jxsUserId');
    loginService.getsaletj({"userid":jxsUserId}).then(result => {
      if (result.data.code == 200) {
        this.data.count = {
          "saleCount": result.data.data.saleCount,//累计销量
          "todaySaleCount": result.data.data.todaySaleCount,//今日销量
          "yesterdaySaleCount": result.data.data.yesterdaySaleCount,//昨日销售
        }
        this.setData({
          count:this.data.count
        })
        wx.setStorageSync('cacheTime', new Date().getTime()+3600000);
        wx.setStorageSync('saleCount', result.data.data.saleCount);
        wx.setStorageSync('tdSaleCount', result.data.data.todaySaleCount);
        wx.setStorageSync('ydSaleCount', result.data.data.yesterdaySaleCount);
      } else {
          // common.showToast(result.data.message)
      }
    })
  },
  getUsers() {
    loginService.getUserInfo({}).then(result => {
      if (result.data.code == 200) {
        if (!("wxtx" in result.data.data)) {
          this.setData({
            hasUserInfo: false
          })
        } else {
          let userInfos = {"nickName":result.data.data.wxnc,"avatarUrl":result.data.data.wxtx,"id":result.data.data.id}
          this.setData({
            userInfo:userInfos,
            hasUserInfo: true
          })
        }
      } else {
          // common.showToast(result.data.message)
      }
    })
  },
  getUserInfo() {
    wx.getUserProfile({ desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写 
    success: (res) => { 
      loginService.saveUserInfo({nickname:res.userInfo.nickName,avatar:res.userInfo.avatarUrl}).then(result => {
        if (result.data.code == 200) {
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        } else {
            // common.showToast(result.data.message)
        }
      })
    }, 
    fail: res => { 
      console.log("获取用户信息失败", res) 
    } 
  })
  },
  bindSalesSave:function(){
    wx.navigateTo({
      url: '../sales/save',
    })
  },
  bindStockSave:function(){
    let url = '../stock/list';
    if (this.data.roleid == 5) {
      url = '../zdstock/list'
    }
    wx.navigateTo({
      url: url,
    })
  },
  bindToMenu:function(e){
    wx.navigateTo({
      url: this.data.menus[e.currentTarget.dataset.index].url
    })
  },
  hideview:function(){
    this.setData({
      display:"none"
    })
  },
  getDaiBan:function(params){
    let list = []
    let that = this
    loginService.getDaiBan(params).then(result => {
      if (result.data.code == 200 && that.data.roleid != 4) {
        let data = result.data.data;
        let isShow = "none";
        for(var i in data) {
          if (data.users.length == 0 && data.allotKcs.length == 0 && data.orders.length == 0){
            isShow = "none";
          } else {
            isShow = "block";
            if (data[i].length > 0) {
              list.push({
                name:"你有"+data[i].length+"条"+that.data.type[i]+"数据待审批",
                status:that.data.status[i],
              })
            }
          }
        }
        this.setData({
          frameData:list,
          display:isShow
        })
      } else {
          // common.showToast(result.data.message)
      }
    })
  },
  bindToUrl:function(e){
    app.globalData.status = e.currentTarget.dataset.status
    wx.switchTab({
      url:"../message/message"
    })
  }
})

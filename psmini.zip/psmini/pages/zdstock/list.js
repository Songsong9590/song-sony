// index.js
// 获取应用实例
const app = getApp()
const goodsService = require("../../service/goodsService.js");
const common = require("../../assets/js/common.js");
const employeeService = require("../../service/employeeService.js");
const config = require('../../utils/config.js');

Page({
  data: {
    stockList:[],
    stockAllList:[],
    roleid:"",
    goods:[],
    params:{
      "userid":"",
      "spid":"",
      "subJxsUserid":""
    },
    index:0,
    dealerList:[],
    dealerIndex:0
  },
  onLoad() {
    let list = [];
    let jxsUserId = wx.getStorageSync('jxsUserId');
    let roleid = wx.getStorageSync('roleid')
    this.setData({
      roleid:roleid,
      "params.userid":jxsUserId
    })
    this.getZbSpKcList()
    this.getProductList()
    this.getDealerList()
    
  },
  getZbSpKcList:function(){
    let list = []
    goodsService.getZbSpKcList(this.data.params).then(res => {
      if (res.data.code == 200) {
        let stock = res.data.data;
        for (var i=0;i<stock.length;i++){ 
          list.push({
            name:stock[i].spXx.sku,
            num: stock[i].kc,
            storenum: stock[i].storekcsum,
            dealer:stock[i].jxsUser.name,
            allnum:stock[i].kc+stock[i].storekcsum
          })
        }
        this.setData({
          stockAllList:list
        })
      } else {
          common.showToast(res.data.message)
      }
    })
  },
  getProductList:function(){
    let goods = []
    goodsService.getSpAll({}).then(res => {
      if (res.data.code == 200) {
        goods = [{"name":"全部商品","id":null}]
        for (var i=0; i<res.data.data.length; i++){
          goods.push({
            name:res.data.data[i].spmc,
            id: res.data.data[i].id
          })
          this.setData({
            goods:goods
          })
        }
      } else {
          common.showToast(resChildren.data.message)
      }
    })
  },
  bindBack:function() {
    wx.navigateTo({
      url: '../total_stock/stock'
    })
  },
  bindSave:function() {
    wx.navigateTo({
      url: '../total_stock/save'
    })
  },
  bindSubmit:function(){
    wx.navigateTo({
      url: '../stock/stock'
    })
  },
  bindPickerChange:function(e){
    this.setData({
      'params.spid': this.data.goods[e.detail.value].id?this.data.goods[e.detail.value].id:"",
      index:e.detail.value
    })
    this.getZbSpKcList()
  },
  bindPickerChangeDealer:function(e){
    this.setData({
      'params.subJxsUserid': this.data.dealerList[e.detail.value].id?this.data.dealerList[e.detail.value].id:"",
      dealerIndex:e.detail.value
    })
    this.getZbSpKcList()
  },
  getDealerList:function(){
    let list = []
    let jxsUserId = wx.getStorageSync('jxsUserId');
    employeeService.getDealerList({"userid":jxsUserId}).then(res => {
      if (res.data.code == 200) {
        list = [{"name":"全部经销商","id":null}]
        let dealer = res.data.data;
        for (var i=0;i<dealer.length;i++){ 
          list.push({
            name:dealer[i].jxsUser.name,
            id:dealer[i].jxsUser.id
          })
          this.setData({
            dealerList:list
          })
        }
      } else {
          common.showToast(res.data.message)
      }
    })
  },
})

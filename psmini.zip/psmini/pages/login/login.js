// index.js
// 获取应用实例
const app = getApp()
const loginService = require("../../service/loginService.js");
const common = require("../../assets/js/common.js");
const cache = require('../../utils/cache.js');
Page({
  data: {
    username:null,
    password:null,
    isChenked:false
  },
  onLoad() {
    console.log(app.globalData.isAuthorize)
  },
  onShow() {
    wx.login({
      success: res => {
          // 发送 res.code 到后台换取 openId, sessionKey, unionId
          if (res.code) {
            loginService.authLogin({code:res.code}).then(result => {
              if (result.data.code == 200) {
                wx.setStorageSync('token', result.data.data.token);
              } else {
                  common.showToast(result.data.message)
              }
          })
          } else {
              console.log('获取用户登录态失败！' + res.errMsg)
          }
      }
    })
  },
  bindLogin() {
    if (!this.data.isChenked) {
      wx.showToast({
        title:"请认真阅读后勾选隐私政策!",
        icon:"none"
      })
      return false;
    }
    let info = wx.getSystemInfoSync();
    console.log(wx.getSystemInfoSync());
    if (!this.data.username || !this.data.password) {
      wx.showToast({
        title:"账号或密码不能为空!",
        icon:"none"
      })
      return false;
    }
    wx.showLoading({
      title: '登陆中...'
    })
    var formData = {
      'account': this.data.username,
      'password': this.data.password, 
  }
    // 发送 res.code 到后台换取 openId, sessionKey, unionId
    loginService.loginP(formData).then(res => {
      console.log(res)
      if (res.data.code == 200) {
        wx.hideLoading()
        if (res.data.data.code == 200) {
          wx.removeStorageSync('jxsUserId')
          wx.removeStorageSync('saleCount');
          wx.removeStorageSync('tdSaleCount');
          wx.removeStorageSync('ydSaleCount');
          wx.setStorageSync('jxsUserId', res.data.data.data.id);
          cache.put('jxsUserId', res.data.data.data.id,86400);
          wx.setStorageSync('roleid', res.data.data.data.roleid);
          wx.setStorageSync('roleName', res.data.data.data.name);
          if(res.data.data.data.userStores[0]){
            wx.setStorageSync('storeId', res.data.data.data.userStores[0].storeid);
          }
          if (res.data.data.data.roleid == 2 && info.platform === 'android'){
            wx.requestSubscribeMessage({
              tmplIds: ['7jafeoAsuOxJe5J1HM_X8ASS3GdLwcPsvz4aJwyioQQ'],
              success (res) {
                app.globalData.isAuthorize = true
                wx.switchTab({
                  url: '/pages/work/work'
                })
              },
            })
          } else {
            wx.switchTab({
              url: '/pages/work/work'
            })
          }
        } else {
          common.showToast(res.data.data.message)
        }
      } else {
          common.showToast(res.data.message)
      }
  })
  },
  usernameInput:function(e)
  {
    this.setData({
      username: e.detail.value
    })
  },
  passwordInput:function(e)
  {
    this.setData({
      password: e.detail.value
    })
  },
  //忘记密码
  bindForgetPassword:function()
  {
    wx.navigateTo({
      url: '/pages/forget/forget'
    })
  },
  checkboxChange:function(e){
    var status = this.data.isChenked ? false :true;
    this.setData({
      isChenked: status
    })
  },
  //查看隐私政策详情
  bindView:function()
  {
    wx.navigateTo({
      url: '/pages/policy/index'
    })
  }
})

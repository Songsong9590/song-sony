const app = getApp()
const goodsService = require("../../service/goodsService.js");
const common = require("../../assets/js/common.js");
const config = require('../../utils/config.js');
Page({
  data: {
    cateItems: [],
    curNav: 1,
    curIndex: 0
  },
  onLoad() {
    goodsService.getSpTypeAll({}).then(res => {
      if (res.data.code == 200) {
        let cateId = 0;
        let typeList = []
        for (var i=0;i<res.data.data.length;i++){ 
          cateId++;
           typeList.push({
            cate_id:cateId,
            cate_name:res.data.data[i].name,
            ishaveChild: true,
            children: [],
            typeId : res.data.data[i].id
          })
          this.setData({
            cateItems:typeList
          })
          if (i == 0) {
            this.getGoodsList({typeid:res.data.data[i].id},i)
          }
        }
      } else {
          common.showToast(res.data.message)
      }
  })
  },
  //事件处理函数  
  switchRightTab: function (e) {
    // 获取item项的id，和数组的下标值  
    let id = e.target.dataset.id,
    typeid = e.target.dataset.typeid,
    index = parseInt(e.target.dataset.index);
    // 把点击到的某一项，设为当前index  
    this.setData({
      curNav: id,
      curIndex: index
    })
    this.getGoodsList({"typeid":typeid},index)
  },
  getGoodsList(params = {},index) {
    let goods = []
    goodsService.getSpAll(params).then(res => {
      if (res.data.code == 200) {
        for (var i=0; i<res.data.data.length; i++){
          goods.push({
            name:res.data.data[i].spmc,
            img: config.DOMAIN +res.data.data[i].img
          })
          this.data.cateItems[index].children = goods;
          this.setData({
            cateItems:this.data.cateItems
          })
        }
      } else {
          common.showToast(resChildren.data.message)
      }
    })
  },
})  
//正式地址
const DOMAIN = 'https://sony.zikudata.com'
const NODOMAIN = 'https://sony.zikudata.com'
// const DOMAIN = 'https://sonybate.reflink.cn'
// const NODOMAIN = 'https://sonybate.reflink.cn'
const program = '1'
const original = 'gh_377225a4a9fb'  // 原始公众号id

module.exports.DOMAIN = DOMAIN
exports.NODOMAIN = NODOMAIN
exports.ORIGINAL = original
exports.PROGRAM = program